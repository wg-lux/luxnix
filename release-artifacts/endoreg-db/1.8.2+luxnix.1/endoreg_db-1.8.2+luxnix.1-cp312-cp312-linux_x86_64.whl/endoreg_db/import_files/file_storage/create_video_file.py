# endoreg_db/import_files/storage/create_video_file.py
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, cast
from endoreg_db.import_files.context.import_context import ImportContext
from endoreg_db.import_files.context.ensure_center import ensure_center
from endoreg_db.import_files.file_storage.storage import ensure_context_file_hash
from endoreg_db.models.media.video.video_file import VideoFile
from endoreg_db.models.state.processing_history.processing_history import (
    ProcessingHistory,
)
from endoreg_db.import_files.file_storage.state_management import finalize_failure
from endoreg_db.services.hub.media_integrity import (
    check_video_media_integrity,
    require_reusable_video_raw_source,
    video_integrity_failure_allows_existing_video_reprocessing,
)
from endoreg_db.services.video_files import (
    get_video_by_content_hash,
    get_video_import_processor,
)

logger = logging.getLogger(__name__)


class _NamedCenter(Protocol):
    name: str


@dataclass(frozen=True)
class _HistoryDecision:
    processed: bool
    needs_processing: bool
    can_short_circuit: bool = False


def _context_source_path(ctx: ImportContext) -> Path:
    return ctx.sensitive_path if isinstance(ctx.sensitive_path, Path) else ctx.file_path


def _bind_video_processor(
    ctx: ImportContext, video: VideoFile, *, required: bool = True
) -> None:
    processor = get_video_import_processor(video)
    if processor is None or not processor.name:
        if required:
            raise ValueError(f"Video {video.pk} has no canonical import processor")
        return
    ctx.processor_name = str(processor.name)


def _load_current_video(
    ctx: ImportContext, file_hash: str, *, require_raw_source: bool = True
) -> VideoFile | None:
    if isinstance(ctx.current_video, VideoFile):
        if require_raw_source:
            require_reusable_video_raw_source(ctx.current_video)
        _bind_video_processor(
            ctx, ctx.current_video, required=require_raw_source or ctx.force_reprocess
        )
        return ctx.current_video
    try:
        ctx.current_video = get_video_by_content_hash(file_hash)
    except VideoFile.DoesNotExist:
        ctx.current_video = None
    if require_raw_source and isinstance(ctx.current_video, VideoFile):
        require_reusable_video_raw_source(ctx.current_video)
    if isinstance(ctx.current_video, VideoFile):
        _bind_video_processor(
            ctx, ctx.current_video, required=require_raw_source or ctx.force_reprocess
        )
    return ctx.current_video if isinstance(ctx.current_video, VideoFile) else None


def _handle_success_history(ctx: ImportContext, file_hash: str) -> _HistoryDecision:
    logger.info(
        "VideoFile already has successful processing history (file_hash=%s) "
        "- checking media integrity before short-circuiting",
        file_hash,
    )
    existing_video = _load_current_video(ctx, file_hash, require_raw_source=False)
    integrity_result = check_video_media_integrity(
        existing_video,
        content_hash=file_hash,
    )
    if integrity_result.ok:
        if existing_video is not None and not existing_video.raw_file:
            if (
                existing_video.center.center_key != ctx.center_key
                if ctx.center_key is not None
                else existing_video.center.name != ctx.center_name
            ):
                raise ValueError("Transferred video belongs to a different center")
        return _HistoryDecision(
            processed=True,
            needs_processing=False,
            can_short_circuit=True,
        )

    if existing_video is not None:
        require_reusable_video_raw_source(existing_video)

    logger.warning(
        "Successful processing history exists for %s but media integrity "
        "failed in create_or_retrieve_video_file: %s. Continuing "
        "reimport so the processed artifact can be repaired.",
        file_hash,
        integrity_result.reason,
    )
    if isinstance(
        ctx.current_video, VideoFile
    ) and not video_integrity_failure_allows_existing_video_reprocessing(
        integrity_result
    ):
        ctx.current_video = None
    return _HistoryDecision(processed=False, needs_processing=True)


def _handle_failure_history(ctx: ImportContext, file_hash: str) -> None:
    if _load_current_video(ctx, file_hash) is None:
        logger.warning(
            "Failed ProcessingHistory exists for %s but no VideoFile could be "
            "loaded; continuing with a fresh import.",
            file_hash,
        )
        return
    ctx.retry = True
    finalize_failure(ctx)


def _get_or_create_video_instance(
    ctx: ImportContext,
    *,
    file_path: Path,
    file_hash: str,
) -> VideoFile:
    if isinstance(ctx.current_video, VideoFile):
        video = ctx.current_video
        require_reusable_video_raw_source(video)
        _bind_video_processor(ctx, video)
        logger.info("Using existing VideoFile from context: pk=%s", video.pk)
        return video

    logger.info(
        "Creating new VideoFile from %s for center %s",
        file_path,
        ctx.center_name,
    )
    video = VideoFile.create_from_file_initialized(
        file_path=file_path,
        center_name=ctx.center_name,
        center_key=ctx.center_key,
        processor_name=ctx.processor_name,
        raw_video_hash=file_hash,
        initialize=not bool(getattr(ctx, "defer_video_initialization", False)),
    )
    _bind_video_processor(ctx, video)

    center = cast(
        _NamedCenter, ensure_center(video, ctx.center_name, center_key=ctx.center_key)
    )
    center_name = str(center.name)
    logger.info("Successfully set up video file from %s", center_name)
    return video


def _record_processing_attempt(file_hash: str, *, has_success_history: bool) -> None:
    if not has_success_history:
        ProcessingHistory.get_or_create_for_hash(
            file_hash=file_hash,
            success=False,
        )
        return

    logger.info(
        "Reprocessing video hash %s to repair failed media integrity without "
        "downgrading successful ProcessingHistory before finalization.",
        file_hash,
    )


def create_or_retrieve_video_file(
    ctx: ImportContext,
) -> tuple[VideoFile, bool, bool]:
    """
    Create a new or retrieve an existing VideoFile for the given context.

    Returns:
        video           : VideoFile instance
        processed       : True if there is already a successful ProcessingHistory for this file
        needs_processing: True if the pipeline should run for this file in this call
    """
    file_path = _context_source_path(ctx)
    file_type = ctx.file_type  # logical key for history; can be None
    file_hash = ensure_context_file_hash(ctx)
    processed = False
    needs_processing = True

    has_success_history = ProcessingHistory.has_history_for_hash(
        file_hash=file_hash,
        success=True,
    )
    has_failure_history = ProcessingHistory.has_history_for_hash(
        file_hash=file_hash,
        success=False,
    )

    if has_success_history:
        decision = _handle_success_history(ctx, file_hash)
        processed = decision.processed
        needs_processing = decision.needs_processing
        if decision.can_short_circuit:
            assert isinstance(ctx.current_video, VideoFile)
            return ctx.current_video, processed, needs_processing
    elif has_failure_history:
        _handle_failure_history(ctx, file_hash)

    video = _get_or_create_video_instance(
        ctx,
        file_path=file_path,
        file_hash=file_hash,
    )
    if not isinstance(ctx.current_video, VideoFile):
        ctx.current_video = video
    _record_processing_attempt(file_hash, has_success_history=has_success_history)

    logger.info(
        "Video instance ready for processing: pk=%s, file_type=%s (needs_processing=True)",
        video.pk,
        file_type,
    )

    return video, processed, needs_processing
