import logging
from pathlib import Path
from uuid import uuid4

from endoreg_db.import_files.context.import_context import ImportContext
from endoreg_db.schemas.import_file import SourceSnapshot
from endoreg_db.services.video_files._imports import atomic_copy_with_fallback
from endoreg_db.utils.file_operations import ensure_directory
from endoreg_db.utils.file_operations import (
    atomic_report_source_snapshot,
    safe_unlink_file,
)
from endoreg_db.utils.hashs import get_file_hash
from endoreg_db.services.hub.upload_job_files import record_working_file

logger = logging.getLogger(__name__)


def ensure_dir(path: Path) -> None:
    ensure_directory(path)


def ensure_context_file_hash(ctx: ImportContext) -> str:
    """Keep an established source identity, otherwise hash the original input."""
    if not isinstance(ctx.file_hash, str):
        ctx.file_hash = get_file_hash(ctx.file_path)
    return ctx.file_hash


def create_sensitive_copy(src: Path, sensitive_root: Path, ctx: ImportContext) -> Path:
    """
    Create a sensitive copy of `src` in `sensitive_root`.

    Returns:
        Path to the sensitive copy.
    """
    expected_hash = ctx.file_hash or get_file_hash(src)
    ensure_dir(sensitive_root)
    hash_prefix = expected_hash[:16]
    staging_dir = ensure_directory(sensitive_root / f"{hash_prefix}-{uuid4().hex}")
    dest = staging_dir / src.name
    record_working_file(dest)
    logger.info("Creating sensitive copy: %s -> %s", src, dest)
    atomic_copy_with_fallback(src, dest)
    try:
        if get_file_hash(dest) != expected_hash:
            raise ValueError(
                "Video staging content differs from import source identity"
            )
    except (OSError, RuntimeError, ValueError):
        safe_unlink_file(dest, missing_ok=True)
        raise
    ctx.file_hash = expected_hash
    return dest


def create_snapshot(
    src: Path,
    sensitive_root: Path,
) -> SourceSnapshot:
    """Create one immutable, content-addressable report import snapshot."""
    ensure_dir(sensitive_root)
    staging_dir = ensure_directory(sensitive_root / f"report-attempt-{uuid4().hex}")
    destination = staging_dir / src.name
    record_working_file(destination)
    logger.info("Creating stable sensitive report snapshot: %s -> %s", src, destination)
    return atomic_report_source_snapshot(
        source=src,
        destination=destination,
    )
