from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar, Any, Unpack

from datetime import datetime as dt

from django.db import models
from django.core.exceptions import ValidationError
from endoreg_db.helpers.typing import DjangoModelSaveKwargs
from lx_dtypes.models.contracts.json_types import JsonObject
from lx_dtypes.models.ledger.medical.Write import PatientMedicationScheduleCreate
from pydantic import ValidationError as PydanticValidationError


if TYPE_CHECKING:
    from ..medication import (
        Medication,
        MedicationIndication,
        MedicationIntakeTime,
        MedicationSchedule,
    )
    from .patient_medication import PatientMedication
    from ...administration.person.patient.patient import Patient
    from ....utils.links import ModelLinks


class PatientMedicationSchedule(models.Model):
    """
    Represents a collection of medications associated with a patient, forming their schedule.
    """

    patient: models.ForeignKey[Any] = models.ForeignKey(
        "Patient", on_delete=models.CASCADE
    )
    medication: models.ManyToManyField[
        "PatientMedication",
        "PatientMedication",
    ] = models.ManyToManyField(
        "PatientMedication", related_name="patient_medication_schedules", blank=True
    )

    # None identifies a legacy flat plan; [] is an explicitly empty BMP plan.
    blocks: models.JSONField[list[JsonObject] | None, list[JsonObject] | None] = (
        models.JSONField(null=True, blank=True)
    )

    def clean(self) -> None:
        super().clean()
        if self.blocks is not None:
            try:
                PatientMedicationScheduleCreate.model_validate({"blocks": self.blocks})
            except PydanticValidationError as exc:
                raise ValidationError(
                    {"blocks": "Invalid medication plan blocks."}
                ) from exc

    def save(self, *args: object, **kwargs: Unpack[DjangoModelSaveKwargs]) -> None:
        self.clean()
        super().save(*args, **kwargs)

    created_at: models.DateTimeField[Any, Any] = models.DateTimeField(auto_now_add=True)
    updated_at: models.DateTimeField[Any, Any] = models.DateTimeField(auto_now=True)

    objects: ClassVar[models.Manager["PatientMedicationSchedule"]] = (  # pyright: ignore[reportIncompatibleVariableOverride]
        models.Manager()
    )

    @property
    def links(self) -> "ModelLinks":
        """
        Aggregates ModelLinks from all PatientMedication instances in this schedule.
        """
        from ....utils.links import ModelLinks

        aggregated_medications: list["Medication"] = []
        aggregated_medication_indications: list["MedicationIndication"] = []
        aggregated_medication_intake_times: list["MedicationIntakeTime"] = []

        patient_meds_in_schedule: list["PatientMedication"] = list(
            self.medication.all()
        )

        for pm_instance in patient_meds_in_schedule:
            pm_links_obj = pm_instance.links

            aggregated_medications.extend(pm_links_obj.medications)
            aggregated_medication_indications.extend(
                pm_links_obj.medication_indications
            )
            aggregated_medication_intake_times.extend(
                pm_links_obj.medication_intake_times
            )

        return ModelLinks(
            medications=list(set(aggregated_medications)),
            medication_indications=list(set(aggregated_medication_indications)),
            medication_intake_times=list(set(aggregated_medication_intake_times)),
            patient_medications=patient_meds_in_schedule,
            patient_medication_schedules=[self],
        )

    def __str__(self) -> str:
        """Returns a string representation including the patient and associated medications."""
        return f"{self.patient} - {self.medication.all()}"

    @classmethod
    def create_by_patient_and_indication_type(
        cls, patient: "Patient", indication_type: str
    ) -> "PatientMedicationSchedule":
        """Creates a schedule and adds a medication based on a random indication of a given type."""
        from .patient_medication import PatientMedication
        from ..medication.medication_indication_type import MedicationIndicationType

        medication_indication = MedicationIndicationType.get_random_indication_by_type(
            name=indication_type
        )

        patient_medication_schedule = cls.objects.create(patient=patient)
        patient_medication_schedule.save()

        patient_medication = PatientMedication.create_by_patient_and_indication(
            patient, medication_indication
        )
        patient_medication_schedule.medication.add(patient_medication)
        patient_medication_schedule.save()

        return patient_medication_schedule

    @classmethod
    def create_by_patient_and_indication(
        cls,
        patient: "Patient",
        medication_indication: "MedicationIndication",
    ) -> "PatientMedicationSchedule":
        """Creates a schedule and adds a medication based on a specific indication."""
        from .patient_medication import PatientMedication

        patient_medication_schedule = cls.objects.create(patient=patient)
        patient_medication_schedule.save()

        patient_medication = PatientMedication.create_by_patient_and_indication(
            patient, medication_indication
        )
        patient_medication_schedule.medication.add(patient_medication)
        patient_medication_schedule.save()

        return patient_medication_schedule

    def create_patient_medication_from_medication_schedule(
        self,
        medication_schedule: "MedicationSchedule",
        medication_indication: "MedicationIndication | None" = None,
        start_date: dt | None = None,
    ) -> "PatientMedication":
        """Creates and adds a PatientMedication based on a generic MedicationSchedule template."""

        from .patient_medication import PatientMedication

        drug = medication_schedule.medication
        unit = medication_schedule.unit
        dosage = medication_schedule.dose
        intake_times = medication_schedule.get_intake_times()

        patient_medication = PatientMedication.objects.create(
            patient=self.patient,
            medication=drug,
            medication_indication=medication_indication,
            unit=unit,
            dosage=dosage,
        )

        patient_medication.intake_times.set(intake_times)
        patient_medication.save()

        self.medication.add(patient_medication)
        self.save()

        return patient_medication

    def get_patient_medication(self) -> models.QuerySet["PatientMedication"]:
        """Returns all PatientMedication instances associated with this schedule."""
        return self.medication.all()
