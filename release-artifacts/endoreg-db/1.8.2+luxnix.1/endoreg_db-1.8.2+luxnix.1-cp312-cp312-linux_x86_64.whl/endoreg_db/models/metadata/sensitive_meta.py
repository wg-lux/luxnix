from __future__ import annotations

# pyright: reportPrivateUsage=false, reportUnusedFunction=false, reportUnusedClass=false
import logging

# Removed hash utils, datetime, random, os, timezone, sha256 imports
# Removed icecream import (was used in old save sensitive_meta_logic)
from typing import TYPE_CHECKING, ClassVar, Protocol, Unpack, cast, Any

from django.db import models, transaction
from lx_dtypes.models.meta.SensitiveMeta import SensitiveMeta as LxSensitiveMeta
from endoreg_db.helpers.typing import DjangoModelSaveKwargs
from endoreg_db.schemas.anonymization import normalize_direct_identifier_tombstone
from endoreg_db.services.secret_rotation.identity import identity_rotation_transaction


# Import models needed for type hints and FKs
from ..state import SensitiveMetaState  # Needed for post-save state check

# Import sensitive_meta_logic functions
from . import sensitive_meta_logic

if TYPE_CHECKING:
    from ..administration import (
        Examiner,  # Keep for type hinting if needed
    )
    from endoreg_db.models.administration.center.center import Center
    from endoreg_db.models.administration.person.patient.patient import Patient
    from endoreg_db.models.administration.person.patient.patient_external_id import (
        PatientExternalID,
    )
    from endoreg_db.models.other.gender import Gender
    from endoreg_db.models.other.tag import Tag
    from endoreg_db.models.medical.patient.patient_examination import PatientExamination
    # from ..state import SensitiveMetaState # Already imported above


class _ExternalIdLike(Protocol):
    origin: str


logger = logging.getLogger(__name__)  # Add logger instance


class SensitiveMeta(models.Model):
    """
    Stores potentially sensitive information extracted from media.
    Logic for creation, hashing, pseudo-anonymization, and saving is in sensitive_meta_logic.py.
    """

    objects: ClassVar[models.Manager["SensitiveMeta"]] = models.Manager()  # pyright: ignore[reportIncompatibleVariableOverride]

    def __init__(self, *args: object, **kwargs: object) -> None:
        first_name = kwargs.pop("first_name", None)
        if first_name is not None and "patient_first_name" not in kwargs:
            kwargs["patient_first_name"] = first_name

        last_name = kwargs.pop("last_name", None)
        if last_name is not None and "patient_last_name" not in kwargs:
            kwargs["patient_last_name"] = last_name

        dob = kwargs.pop("dob", None)
        if dob is not None and "patient_dob" not in kwargs:
            kwargs["patient_dob"] = dob

        center = kwargs.get("center")
        if isinstance(center, str):
            from endoreg_db.models.administration.center.center import Center

            kwargs["center"] = Center(name=center)

        super().__init__(*args, **kwargs)

    # --- Examination and Patient Info ---
    examination_date: models.DateField[Any, Any] = models.DateField(
        blank=True, null=True
    )
    examination_time: models.TimeField[Any, Any] = models.TimeField(
        blank=True, null=True
    )
    casenumber: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    file_path: models.CharField[Any, Any] = models.CharField(
        max_length=1024, blank=True, null=True
    )

    # --- Core FKs ---
    pseudo_patient: models.ForeignKey["Patient | None"] = models.ForeignKey(
        "Patient",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="FK to the pseudo-anonymized Patient record.",
    )
    pseudo_examination: models.ForeignKey["PatientExamination | None"] = (
        models.ForeignKey(
            "PatientExamination",
            on_delete=models.CASCADE,
            blank=True,
            null=True,
            help_text="FK to the pseudo-anonymized PatientExamination record.",
        )
    )
    patient_gender: models.ForeignKey["Gender | None"] = models.ForeignKey(
        "Gender", on_delete=models.CASCADE, blank=True, null=True
    )
    if TYPE_CHECKING:
        examiners: models.ManyToManyField["Examiner", "Examiner"]

    examiners: models.ManyToManyField["Examiner", "Examiner"] = models.ManyToManyField(
        "Examiner", blank=True, help_text="Pseudo-anonymized examiner(s)"
    )
    tags: models.ManyToManyField["Tag", "Tag"] = models.ManyToManyField(
        "Tag", blank=True, help_text="Validation tags"
    )
    center: models.ForeignKey["Center | None"] = models.ForeignKey(
        "Center", on_delete=models.CASCADE, blank=True, null=True
    )

    if TYPE_CHECKING:
        pseudo_patient_id: int | None
        pseudo_examination_id: int | None
        patient_gender_id: int | None
        center_id: int | None

    # --- Names and DOB ---
    patient_first_name: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    patient_last_name: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    patient_dob: models.DateTimeField[Any, Any] = models.DateTimeField(
        blank=True, null=True, help_text="Date of birth (can be auto-generated)."
    )

    examiner_first_name: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True, editable=False
    )
    examiner_last_name: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True, editable=False
    )

    # --- Hashes ---
    patient_hash: models.CharField[Any, Any] = models.CharField(
        max_length=64, blank=True, null=True, editable=False, db_index=True
    )
    examination_hash: models.CharField[Any, Any] = models.CharField(
        max_length=64, blank=True, null=True, editable=False, db_index=True
    )
    identity_fingerprint: models.CharField[Any, Any] = models.CharField(
        max_length=64, blank=True, default="", editable=False
    )
    identity_salt_fingerprint: models.CharField[Any, Any] = models.CharField(
        max_length=64, blank=True, default="", editable=False
    )

    # --- Endoscope Info ---
    endoscope_type: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    endoscope_sn: models.CharField[Any, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )

    # --- External patient ID ---
    external_id: models.ForeignKey["PatientExternalID | None"] = models.ForeignKey(
        "PatientExternalID", on_delete=models.CASCADE, blank=True, null=True
    )

    if TYPE_CHECKING:
        state: SensitiveMetaState | None

    @property
    def external_id_origin(self) -> str | None:
        """Returns the origin system from the linked external ID, if available."""
        if self.external_id:
            return cast(_ExternalIdLike, self.external_id).origin
        return None

    # --- Text Fields ---
    text: models.TextField[Any, Any] = models.TextField(blank=True, null=True)
    anonymized_text: models.TextField[Any, Any] = models.TextField(
        blank=True, null=True
    )
    validation_comment: models.TextField[Any, Any] = models.TextField(
        blank=True, default=""
    )
    direct_identifiers_cleared_at: models.DateTimeField[Any, Any] = (
        models.DateTimeField(blank=True, null=True)
    )
    direct_identifier_policy: models.CharField[Any, Any] = models.CharField(
        max_length=64,
        blank=True,
        default="",
    )
    direct_identifier_tombstone: models.JSONField[dict[str, object]] = models.JSONField(
        default=dict, blank=True
    )

    def clean(self) -> None:
        super().clean()
        self.direct_identifier_tombstone = normalize_direct_identifier_tombstone(
            self.direct_identifier_tombstone
        )

    # --- Anonymization helper method ---
    create_anonymized_record = sensitive_meta_logic._create_anonymized_record

    # --- State ---
    @property
    def state_verified(self) -> bool:
        """Compatibility alias for the canonical verification result."""
        return self.is_verified

    @classmethod
    def create_from_dict(
        cls: type["SensitiveMeta"], data: dict[str, Any]
    ) -> "SensitiveMeta":
        """Compatibility facade for the patient_identity dictionary-ingestion service."""
        from endoreg_db.services.patient_identity.sensitive_meta_ingestion import (
            create_sensitive_meta_from_dict,
        )

        return create_sensitive_meta_from_dict(cls, data)

    def get_pseudo_examiner(self) -> "Examiner | None":
        """Returns the linked pseudo examiner, if one exists."""
        if self.pk:
            return self.examiners.first()
        return None  # Cannot determine before saving and linking

    def update_from_dict(self, data: dict[str, Any]) -> "SensitiveMeta":
        """Compatibility facade for the patient_identity dictionary-ingestion service."""
        from endoreg_db.services.patient_identity.sensitive_meta_ingestion import (
            update_sensitive_meta_from_dict,
        )

        return update_sensitive_meta_from_dict(self, data)

    def update_from_lx_sensitive_meta(
        self, sensitive_meta: LxSensitiveMeta
    ) -> "SensitiveMeta":
        """Updates this instance from the lx_dtypes SensitiveMeta contract."""
        data = sensitive_meta.to_dict()
        payload: dict[str, Any] = {
            "file_path": data.get("file_path"),
            "patient_first_name": data.get("first_name"),
            "patient_last_name": data.get("last_name"),
            "patient_dob": data.get("dob"),
            "casenumber": data.get("casenumber"),
            "examination_date": data.get("examination_date"),
            "examination_time": data.get("examination_time"),
            "examiner_first_name": data.get("examiner_first_name"),
            "examiner_last_name": data.get("examiner_last_name"),
            "text": data.get("text"),
            "anonymized_text": data.get("anonymized_text"),
            "endoscope_type": data.get("endoscope_type"),
            "endoscope_sn": data.get("endoscope_sn"),
            "patient_gender": data.get("gender"),
            "center_name": data.get("center"),
        }
        return self.update_from_dict(
            {
                key: value
                for key, value in payload.items()
                if value not in (None, "", [])
            }
        )

    # --- String representation ---
    def __str__(self) -> str:
        # Keep this method for basic representation, ensure fields are accessed safely
        center_name = str(getattr(self.center, "name", "None"))
        gender = getattr(self, "patient_gender", None)
        gender_str = str(gender) if gender else "None"
        dob_str = (
            str(self.patient_dob.date()) if self.patient_dob else "None"
        )  # Show only date part
        exam_date_str = str(self.examination_date) if self.examination_date else "None"

        examiners_str = "[Not saved yet]"
        if self.pk:
            try:
                # Use prefetch_related in queries accessing this for efficiency
                examiners_str = (
                    ", ".join([str(e) for e in self.examiners.all()]) or "[None]"
                )
            except Exception as e:
                examiners_str = f"[Error: {e}]"

        state_verified = "Unknown"
        if self.pk:
            # Access state verification through the related state object
            state_verified = str(self.is_verified)
        else:
            state_verified = "[Not saved yet]"

        return (
            f"SensitiveMeta(pk={self.pk}): "
            f"Patient={self.patient_last_name}, {self.patient_first_name} (*{dob_str}, {gender_str}), "
            f"ExamDate={exam_date_str}, Center={center_name}, "
            f"Examiners={examiners_str}, StateVerified={state_verified}, "
            f"PatientHash={str(self.patient_hash)[-8:] if self.patient_hash else 'None'}, "  # Show last 8 chars
            f"ExamHash={str(self.examination_hash)[-8:] if self.examination_hash else 'None'}"  # Show last 8 chars
        )

    @property
    def state_safe(self) -> "SensitiveMetaState":
        state = self.state
        if not state:
            raise SensitiveMetaState.DoesNotExist(
                "SensitiveMetaState does not exist for this SensitiveMeta instance."
            )
        return state

    @property
    def is_verified(self) -> bool:
        """
        Checks if the instance is verified based on the related state object.
        """
        # Use try-except for robustness, especially if state might not exist yet
        try:
            # Access the related state object directly via the 'state' attribute
            # This assumes the related_name on SensitiveMetaState.origin is 'state'
            return self.state_safe.is_verified
        except SensitiveMetaState.DoesNotExist:
            # If the state object doesn't exist, it's not verified
            return False
        except AttributeError:
            # If the 'state' attribute doesn't exist (e.g., before first save), it's not verified
            return False

    def get_or_create_state(self) -> "SensitiveMetaState":
        """
        Gets the related SensitiveMetaState instance, creating one if it doesn't exist.
        Does not save the SensitiveMeta instance itself.
        """
        from endoreg_db.services.patient_identity.verification import (
            get_or_create_sensitive_meta_state,
        )

        if self.pk is None:
            raise ValueError(
                "Cannot get or create state for an unsaved SensitiveMeta instance."
            )
        self.state = get_or_create_sensitive_meta_state(self.pk)
        return self.state

    def __repr__(self) -> str:
        return self.__str__()

    # --- Hashing methods delegate to sensitive_meta_logic ---
    def calculate_patient_hash(self, salt: str | None = None) -> str:
        """Calculates the patient hash using external sensitive_meta_logic."""
        return sensitive_meta_logic.calculate_patient_hash(self, salt=salt)

    def get_patient_examination_hash(self, salt: str | None = None) -> str:
        """Calculates the examination hash using external sensitive_meta_logic."""
        return sensitive_meta_logic.calculate_examination_hash(self, salt=salt)

    # --- Save method orchestrates calls to sensitive_meta_logic ---
    @transaction.atomic
    @identity_rotation_transaction
    def save(self, *args: object, **kwargs: Unpack[DjangoModelSaveKwargs]) -> None:
        """
        Saves the SensitiveMeta instance, ensuring data integrity, hash calculation, pseudo-entity linking, and related state management using external sensitive_meta_logic.

        This method performs pre-save operations via external sensitive_meta_logic, persists the instance, ensures the related SensitiveMetaState exists, and links the appropriate examiner to the instance.
        """
        from endoreg_db.services.patient_identity.verification import (
            sensitive_meta_verification_guard,
        )

        with sensitive_meta_verification_guard(self):
            # 1. Call the main sensitive_meta_logic function to perform pre-save checks, data generation,
            #    and creation/linking of pseudo patient/examination FKs.
            #    This function modifies the instance fields (hashes, FKs, dates).
            #    It returns the examiner instance to be linked *after* saving.
            self.clean()
            examiner_to_link = sensitive_meta_logic.perform_save_logic(
                self
            )  # Pass only self

            # 2. Call the original Django save method to save the instance itself
            #    (including updated FKs, hashes, dates).
            super().save(*args, **kwargs)  # Pass original args/kwargs

            # 3. Ensure SensitiveMetaState exists *after* saving the main instance
            #    Use related name 'state' if defined, otherwise access via manager.
            if self.pk:  # Ensure we have a PK
                try:
                    # Check if the related state object already exists using the related manager
                    _ = self.state
                except SensitiveMetaState.DoesNotExist:
                    # If not, create a new one, linking it to the saved instance
                    SensitiveMetaState.objects.create(origin=self)
                except AttributeError:
                    # Fallback check if 'state' related_name is missing
                    if not SensitiveMetaState.objects.filter(origin=self).exists():
                        SensitiveMetaState.objects.create(origin=self)

            # 4. Handle ManyToMany linking (examiners) *after* the instance has a PK.
            if (
                examiner_to_link
                and self.pk
                and not self.examiners.filter(pk=examiner_to_link.pk).exists()
            ):
                self.examiners.add(examiner_to_link)
                # Adding to M2M handles its own DB interaction, no second super().save() needed.

    def mark_dob_verified(self) -> None:
        """
        Mark the associated date of birth as verified in the related SensitiveMetaState.
        """
        state = self.get_or_create_state()
        state.mark_dob_verified()

    def mark_names_verified(self) -> None:
        """
        Mark the patient's names as verified in the associated verification state.

        This method ensures the related SensitiveMetaState exists and updates its status to indicate that the patient's names have been verified.
        """
        state = self.get_or_create_state()
        state.mark_names_verified()
