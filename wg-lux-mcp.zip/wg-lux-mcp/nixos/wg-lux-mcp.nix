{ config, lib, pkgs, ... }:

let
  cfg = config.services.wg-lux-mcp;
in
{
  options.services.wg-lux-mcp = {
    enable = lib.mkEnableOption "wg-lux read-only MCP server";
    package = lib.mkOption {
      type = lib.types.package;
      description = "Package containing the wg-lux-mcp Python application.";
    };
    environmentFile = lib.mkOption {
      type = lib.types.path;
      description = "Environment file containing WG_LUX_MCP_* settings.";
    };
    user = lib.mkOption { type = lib.types.str; default = "wg-lux-mcp"; };
    group = lib.mkOption { type = lib.types.str; default = "wg-lux-mcp"; };
  };

  config = lib.mkIf cfg.enable {
    users.users.${cfg.user} = {
      isSystemUser = true;
      group = cfg.group;
    };
    users.groups.${cfg.group} = {};

    systemd.services.wg-lux-mcp = {
      description = "wg-lux MCP server";
      wantedBy = [ "multi-user.target" ];
      after = [ "network.target" ];
      serviceConfig = {
        User = cfg.user;
        Group = cfg.group;
        EnvironmentFile = cfg.environmentFile;
        ExecStart = "${cfg.package}/bin/uvicorn wg_lux_mcp.asgi:app --host 127.0.0.1 --port 8765 --proxy-headers --forwarded-allow-ips=127.0.0.1";
        Restart = "on-failure";
        RestartSec = "2s";
        NoNewPrivileges = true;
        PrivateTmp = true;
        ProtectHome = true;
        ProtectSystem = "strict";
        ProtectKernelTunables = true;
        ProtectKernelModules = true;
        ProtectControlGroups = true;
        RestrictSUIDSGID = true;
        LockPersonality = true;
        MemoryDenyWriteExecute = true;
        CapabilityBoundingSet = "";
        AmbientCapabilities = "";
        UMask = "0077";
      };
    };
  };
}
