const e=Symbol("report-template-lifecycle-context");export{e as r};
