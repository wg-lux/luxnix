from __future__ import annotations

import json
from pathlib import Path

from mcp.server import MCPServer

from .repo import resolve_repo, run_readonly

mcp = MCPServer(
    "wg-lux-dev",
    instructions=(
        "Read-only development tools for the explicitly allowlisted wg-lux repositories. "
        "Never claim that this server can modify files, Git state, services, or databases."
    ),
)


@mcp.tool()
def list_repositories() -> list[str]:
    """List repository names exposed by this server."""
    from .config import settings

    return sorted(settings.repositories)


@mcp.tool()
def get_repo_status(repo: str) -> dict[str, object]:
    """Return branch, HEAD commit, and porcelain status for one allowlisted repository."""
    path = resolve_repo(repo)
    branch = run_readonly(path, ["git", "branch", "--show-current"]).strip()
    head = run_readonly(path, ["git", "rev-parse", "HEAD"]).strip()
    status = run_readonly(path, ["git", "status", "--porcelain=v1"])
    return {
        "repo": repo,
        "path": str(path),
        "branch": branch,
        "head": head,
        "clean": not bool(status.strip()),
        "status": status.splitlines(),
    }


@mcp.tool()
def get_recent_commits(repo: str, limit: int = 10) -> list[dict[str, str]]:
    """Return recent commits from an allowlisted repository, newest first."""
    if not 1 <= limit <= 50:
        raise ValueError("limit must be between 1 and 50")
    path = resolve_repo(repo)
    raw = run_readonly(
        path,
        [
            "git",
            "log",
            f"-{limit}",
            "--date=iso-strict",
            "--format=%H%x1f%ad%x1f%an%x1f%s",
        ],
    )
    result: list[dict[str, str]] = []
    for line in raw.splitlines():
        commit, date, author, subject = line.split("\x1f", 3)
        result.append({"commit": commit, "date": date, "author": author, "subject": subject})
    return result


@mcp.tool()
def read_text_file(repo: str, relative_path: str, max_chars: int = 20_000) -> dict[str, object]:
    """Read a UTF-8 text file beneath an allowlisted repository root."""
    if not 1 <= max_chars <= 40_000:
        raise ValueError("max_chars must be between 1 and 40000")

    root = resolve_repo(repo)
    requested = (root / relative_path).resolve()
    if requested != root and root not in requested.parents:
        raise ValueError("Path escapes repository root")
    if not requested.is_file():
        raise FileNotFoundError(relative_path)

    data = requested.read_text(encoding="utf-8")
    return {
        "repo": repo,
        "path": str(requested.relative_to(root)),
        "truncated": len(data) > max_chars,
        "text": data[:max_chars],
    }


@mcp.tool()
def get_pyproject(repo: str) -> dict[str, object]:
    """Return pyproject.toml as text plus basic existence metadata."""
    root = resolve_repo(repo)
    path = root / "pyproject.toml"
    if not path.is_file():
        return {"repo": repo, "exists": False, "text": None}
    text = path.read_text(encoding="utf-8")
    return {"repo": repo, "exists": True, "text": text[:40_000]}


@mcp.tool()
def inspect_django_migrations(repo: str, app: str) -> list[str]:
    """List migration filenames for a Django app without importing or executing Django."""
    if not app or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" for c in app):
        raise ValueError("app must be a simple Python identifier")

    root = resolve_repo(repo)
    matches = sorted(root.glob(f"**/{app}/migrations/[0-9][0-9][0-9][0-9]_*.py"))
    return [str(path.relative_to(root)) for path in matches[:500]]


@mcp.tool()
def server_capabilities() -> dict[str, object]:
    """Describe the deliberate security boundary of this server."""
    return json.loads(
        json.dumps(
            {
                "mode": "read-only",
                "shell": False,
                "arbitrary_commands": False,
                "filesystem_scope": "allowlisted repositories only",
                "git_writes": False,
                "database_access": False,
                "service_control": False,
            }
        )
    )
