from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TypedDict, Unpack

from django.core.management.base import BaseCommand, CommandError, CommandParser
from lx_dtypes.models.contracts import (
    VideoAnnotationExportRequestPayload,
    dump_video_annotation_export_update_payload,
)
from lx_dtypes.models.contracts.video_frame_export import (
    VideoFrameAnnotationExportFormat,
)
from pydantic import ValidationError

from endoreg_db.export.frames.export_frames_with_labels import (
    AnnotationExporterClient,
    export_config,
    ExportJobFailedError,
)

# Usage Example:
# python manage.py export_frame_annot \
#   --output-path data/export/frames.csv \
#   --video-id 1 \
#   --only-true \
#   --transcode-frames \
#   --transcode-fps 50


class ExportFrameAnnotOptions(TypedDict):
    config: str | None
    output_path: str | None
    output_dir: str | None
    video_id: int | None
    label_id: int | None
    center_key: str | None
    all_centers: bool | None
    information_source_name: str | None
    only_true: bool | None
    limit: int | None
    load_base_data: bool | None
    export_videos: bool | None
    export_frames: bool | None
    use_export_flags: bool | None
    segment_ids: list[int] | None
    only_validated: bool | None
    transcode_frames: bool | None
    transcode_fps: float | None
    transcode_quality: int | None
    transcode_ext: str | None
    transcode_overwrite: bool | None
    use_frame_pk_paths: bool | None
    format: VideoFrameAnnotationExportFormat | None


class Command(BaseCommand):
    help = (
        "Export frame annotations to CSV with optional transcoding. /n Usage Example: /n python manage.py export_frame_annot \
   --output-path data/export/frames.csv \
   --video-id 1 \
   --only-true \
   --transcode-frames \
   --transcode-fps 50"
    )

    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument(
            "--config",
            type=str,
            help="Path to YAML config for export settings.",
        )
        parser.add_argument(
            "--output-path",
            type=str,
            help="CSV output path (required if --config is not provided).",
        )
        parser.add_argument(
            "--output-dir",
            type=str,
            help="Base output directory for exported assets.",
        )
        parser.add_argument("--video-id", type=int, help="Filter by video id.")
        parser.add_argument("--label-id", type=int, help="Filter by label id.")
        parser.add_argument(
            "--center-key",
            type=str,
            help="Filter export to one center_key.",
        )
        parser.add_argument(
            "--all-centers",
            action="store_true",
            default=None,
            help="Explicitly export all centers.",
        )
        parser.add_argument(
            "--information-source-name",
            type=str,
            help="Filter by information source name.",
        )
        only_true_group = parser.add_mutually_exclusive_group()
        only_true_group.add_argument(
            "--only-true",
            action="store_true",
            default=None,
            help="Only export rows with value=True.",
        )
        only_true_group.add_argument(
            "--only-false",
            action="store_false",
            dest="only_true",
            default=None,
            help="Only export rows with value=False.",
        )
        parser.add_argument("--limit", type=int, help="Limit number of rows.")

        load_base_group = parser.add_mutually_exclusive_group()
        load_base_group.add_argument(
            "--load-base-data",
            action="store_true",
            default=None,
            help="Load base data before export.",
        )
        load_base_group.add_argument(
            "--no-load-base-data",
            action="store_false",
            dest="load_base_data",
            default=None,
            help="Do not load base data before export.",
        )

        export_videos_group = parser.add_mutually_exclusive_group()
        export_videos_group.add_argument(
            "--export-videos",
            action="store_true",
            default=None,
            help="Export videos for annotated data.",
        )
        export_videos_group.add_argument(
            "--no-export-videos",
            action="store_false",
            dest="export_videos",
            default=None,
            help="Do not export videos.",
        )

        export_frames_group = parser.add_mutually_exclusive_group()
        export_frames_group.add_argument(
            "--export-frames",
            action="store_true",
            default=None,
            help="Export frames for annotated data.",
        )
        export_frames_group.add_argument(
            "--no-export-frames",
            action="store_false",
            dest="export_frames",
            default=None,
            help="Do not export frames.",
        )

        export_flag_group = parser.add_mutually_exclusive_group()
        export_flag_group.add_argument(
            "--use-export-flags",
            action="store_true",
            default=None,
            help="Filter annotations by export flags on video/segments.",
        )
        export_flag_group.add_argument(
            "--no-use-export-flags",
            action="store_false",
            dest="use_export_flags",
            default=None,
            help="Do not filter by export flags.",
        )
        parser.add_argument(
            "--segment-ids",
            nargs="+",
            type=int,
            help="Export only annotations from these segment IDs.",
        )
        validated_group = parser.add_mutually_exclusive_group()
        validated_group.add_argument(
            "--only-validated",
            action="store_true",
            default=None,
            help="Export only human anonymization validated media.",
        )
        validated_group.add_argument(
            "--include-unvalidated",
            action="store_false",
            dest="only_validated",
            default=None,
            help="Allow table rows from unvalidated media. Media-backed exports still fail if validation is missing.",
        )

        transcode_group = parser.add_mutually_exclusive_group()
        transcode_group.add_argument(
            "--transcode-frames",
            action="store_true",
            default=None,
            help="Extract frames to frame_dir at configured FPS.",
        )
        transcode_group.add_argument(
            "--no-transcode-frames",
            action="store_false",
            dest="transcode_frames",
            default=None,
            help="Disable frame extraction even if YAML enables it.",
        )
        parser.add_argument("--transcode-fps", type=float, help="Transcode FPS.")
        parser.add_argument(
            "--transcode-quality",
            type=int,
            help="FFmpeg quality (lower is higher quality).",
        )
        parser.add_argument(
            "--transcode-ext",
            type=str,
            help="Output frame extension (e.g. jpg).",
        )
        overwrite_group = parser.add_mutually_exclusive_group()
        overwrite_group.add_argument(
            "--transcode-overwrite",
            action="store_true",
            default=None,
            help="Overwrite existing frames.",
        )
        overwrite_group.add_argument(
            "--no-transcode-overwrite",
            action="store_false",
            dest="transcode_overwrite",
            default=None,
            help="Do not overwrite existing frames.",
        )

        frame_path_group = parser.add_mutually_exclusive_group()
        frame_path_group.add_argument(
            "--use-frame-pk-paths",
            action="store_true",
            default=None,
            help="Write frame_relative_path using frame pk names.",
        )
        frame_path_group.add_argument(
            "--no-use-frame-pk-paths",
            action="store_false",
            dest="use_frame_pk_paths",
            default=None,
            help="Use stored relative_path values for frame_relative_path.",
        )

        parser.add_argument(
            "--format",
            choices=["csv", "json"],
            default=None,
            help="Export format (csv or json). Default: csv",
        )

    def handle(
        self,
        *args: str,
        **options: Unpack[ExportFrameAnnotOptions],
    ) -> None:
        config = self._build_config(options)
        client = AnnotationExporterClient()
        try:
            result = client.run_export(config)
        except ExportJobFailedError as exc:
            raise CommandError(str(exc)) from exc

        self.stdout.write(
            self.style.SUCCESS(
                "Exported %s rows to %s" % (result.row_count, result.output_path)
            )
        )

    def _build_config(self, options: ExportFrameAnnotOptions) -> export_config:
        config_path = options["config"]
        if config_path is not None:
            config = export_config.from_yaml(Path(config_path))
        else:
            output_path = options["output_path"]
            output_dir = options["output_dir"]
            if not output_path:
                output_path = "frames.csv" if output_dir else "data/export/frames.csv"
            config = export_config(output_path=Path(output_path))

        try:
            payload = VideoAnnotationExportRequestPayload(
                output_path=options["output_path"],
                output_dir=options["output_dir"],
                format=options["format"],
                video_id=options["video_id"],
                label_id=options["label_id"],
                information_source_name=options["information_source_name"],
                only_true=options["only_true"],
                limit=options["limit"],
                load_base_data=options["load_base_data"],
                export_videos=options["export_videos"],
                export_frames=options["export_frames"],
                transcode_frames=options["transcode_frames"],
                transcode_fps=options["transcode_fps"],
                transcode_quality=options["transcode_quality"],
                transcode_ext=options["transcode_ext"],
                transcode_overwrite=options["transcode_overwrite"],
                use_frame_pk_paths=options["use_frame_pk_paths"],
                use_export_flags=options["use_export_flags"],
                segment_ids=options["segment_ids"],
                center_key=options["center_key"],
                all_centers=options["all_centers"],
                only_validated=options["only_validated"],
            )
        except ValidationError as exc:
            raise CommandError(str(exc)) from exc

        updates = dump_video_annotation_export_update_payload(payload)

        if updates:
            config = replace(config, **updates)

        if not config.output_path:
            raise CommandError("output_path is required.")

        return config
