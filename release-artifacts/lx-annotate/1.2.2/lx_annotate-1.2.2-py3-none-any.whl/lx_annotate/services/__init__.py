"""Application-owned service boundaries."""
