# wg-lux-mcp

A deliberately read-only MCP server for a small allowlist of wg-lux development repositories.

## Security model

- No shell execution.
- No arbitrary command tool.
- Git commands are hard-coded read-only invocations.
- File reads are constrained to configured repository roots.
- No database, systemd, Git write, package-manager, or network mutation tools.
- The systemd unit runs unprivileged with a read-only OS filesystem.

## Local development

```bash
cp .env.example .env
uv sync --extra dev
uv run uvicorn wg_lux_mcp.asgi:app --host 127.0.0.1 --port 8765
curl http://127.0.0.1:8765/healthz
```

The MCP endpoint is:

```text
http://127.0.0.1:8765/mcp
```

Test with the MCP Inspector or the SDK client.

## Production

1. Clone/copy the three repositories to fixed paths readable by the service user.
2. Set `WG_LUX_MCP_PUBLIC_HOST` and repository paths in an EnvironmentFile.
3. Package this project with `uv2nix`, `pyproject.nix`, or your existing Nix Python packaging pattern.
4. Import `nixos/wg-lux-mcp.nix`, set `services.wg-lux-mcp.package` and `environmentFile`, and enable the service.
5. Put Caddy/nginx in front of `127.0.0.1:8765` and terminate TLS there.
6. Expose `https://mcp.example.org/mcp` or use OpenAI Secure MCP Tunnel instead of public exposure.

## Authentication

`WG_LUX_MCP_BEARER_TOKEN` enables a static Bearer gate for generic MCP clients. Do not treat this as the preferred ChatGPT production identity model.

For ChatGPT, prefer either:

- OAuth/OIDC with refresh-token support, or
- Secure MCP Tunnel for a private/on-premise endpoint.

The exact authentication option is selected when configuring the custom app in ChatGPT.

## ChatGPT setup

Use the endpoint:

```text
https://mcp.example.org/mcp
```

Then scan tools and verify that only read-only operations are present before enabling it for broader use.
