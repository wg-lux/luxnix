from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

if TYPE_CHECKING:
    from ..shift.scheduled_days import ScheduledDays


class CenterShiftManager(models.Manager["CenterShift"]):
    def get_by_natural_key(self, name: str) -> "CenterShift":
        """
        Retrieves a CenterShift instance by its unique name.

        Args:
            name: The unique identifier of the CenterShift.

        Returns:
            The CenterShift instance with the specified name.
        """
        return self.get(name=name)


class CenterShift(models.Model):
    """
    Model representing a center shift.
    """

    name: models.CharField[Any, Any] = models.CharField(max_length=255, unique=True)
    description: models.TextField[Any, Any] = models.TextField(blank=True, null=True)

    center: models.ForeignKey[Any] = models.ForeignKey(
        "Center",
        on_delete=models.CASCADE,
        related_name="center_shifts",
    )
    shift: models.ForeignKey[Any] = models.ForeignKey(
        "Shift",
        on_delete=models.CASCADE,
        related_name="center_shifts",
    )

    start_time: models.TimeField[Any, Any] = models.TimeField()
    end_time: models.TimeField[Any, Any] = models.TimeField()
    scheduled_days: models.ManyToManyField[
        ScheduledDays,
        ScheduledDays,
    ] = models.ManyToManyField(
        "ScheduledDays",
        related_name="center_shifts",
    )

    estimated_presence_fraction: models.DecimalField[Any, Any] = models.DecimalField(
        max_digits=5,
        decimal_places=4,
        default=Decimal("0"),
        validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("1"))],
    )

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=models.Q(
                    estimated_presence_fraction__gte=Decimal("0"),
                    estimated_presence_fraction__lte=Decimal("1"),
                ),
                name="center_shift_presence_fraction_range",
            ),
        ]

    def __str__(self) -> str:
        """
        Returns a string representation of the center shift, combining the center and shift.
        """
        return f"{self.center} - {self.shift}"

    def initialize_scheduled_days(self) -> None:
        """Reject scheduling until an explicit initialization workflow exists."""
        raise NotImplementedError("Scheduled-day initialization is not implemented.")

    def get_scheduled_days(self, infer: bool = True) -> models.QuerySet[ScheduledDays]:
        """
        Retrieves the scheduled days associated with this center shift.

        If no scheduled days are found and `infer` is False, raises a ValueError. Otherwise, returns the queryset of scheduled days, which may be empty.
        """
        sd = self.scheduled_days.all()
        if not sd.exists():
            if not infer:
                raise ValueError("No scheduled days found for this center shift.")

        return sd
