from __future__ import annotations

from typing import TYPE_CHECKING, Any

from django.db import models

if TYPE_CHECKING:
    from ...qualification.qualification import Qualification
    from .employee import Employee


class EmployeeTypeManager(models.Manager["EmployeeType"]):
    def get_queryset(self) -> models.QuerySet["EmployeeType"]:
        """
        Returns a queryset of active employee types.

        Only employee types with is_active set to True are included in the queryset.
        """
        return super().get_queryset().filter(is_active=True)


class EmployeeType(models.Model):
    """
    Model representing an employee type.
    """

    name: models.CharField[Any, Any] = models.CharField(max_length=255, unique=True)
    description: models.TextField[Any, Any] = models.TextField(blank=True, null=True)
    is_active: models.BooleanField[Any, Any] = models.BooleanField(default=True)

    qualifications: models.ManyToManyField[Qualification, Qualification] = (
        models.ManyToManyField(
            "Qualification",
            related_name="employee_types",
        )
    )

    if TYPE_CHECKING:

        @property
        def employees(self) -> models.QuerySet["Employee"]: ...

    objects = EmployeeTypeManager()

    def __str__(self) -> str:
        """
        Returns the name of the employee type as its string representation.
        """
        return str(self.name)
