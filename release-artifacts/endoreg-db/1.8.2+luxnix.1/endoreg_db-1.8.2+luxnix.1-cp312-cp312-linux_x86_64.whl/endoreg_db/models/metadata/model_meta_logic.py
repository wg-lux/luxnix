from __future__ import annotations
from contextlib import contextmanager
from importlib import import_module
from logging import getLogger
from pathlib import Path
from django.core.files.base import ContentFile
from collections.abc import Iterable, Sequence
from typing import TYPE_CHECKING, Protocol, Unpack, cast
from collections.abc import Generator
from uuid import uuid4

from django.db import transaction
from torch import nn

# Assuming ModelMeta, AiModel, LabelSet are importable from the correct locations
# Adjust imports based on your project structure if necessary
from ..administration.ai.ai_model import AiModel
from ..label.label_set import LabelSet
from endoreg_db.utils.paths import get_runtime_paths
from endoreg_db.utils.file_operations import (
    ensure_directory,
    safe_rmtree,
)
from lx_dtypes.models.contracts import model_meta as model_meta_contract
from lx_dtypes.models.contracts.model_meta_logic import (
    ModelMetaCreateFromFileKwargsData,
    ModelMetaCreateFromFileKwargsPayload,
    ModelMetaInferredDefaultsPayload,
)

logger = getLogger("ai_model")

_DEFAULT_HF_WEIGHT_FILENAME = "colo_segmentation_RegNetX800MF_base.safetensors"

if TYPE_CHECKING:
    from endoreg_db.models.metadata.model_meta import ModelMeta


class _AiModelActiveMetaLike(Protocol):
    active_meta_id: int | None
    active_meta: "ModelMeta"
    name: str

    def save(self, *, update_fields: Sequence[str]) -> None: ...


class _HfHubDownload(Protocol):
    def __call__(
        self,
        *,
        repo_id: str,
        filename: str,
        local_dir: str | Path,
    ) -> str: ...


def hf_hub_download(
    *,
    repo_id: str,
    filename: str,
    local_dir: str | Path,
) -> str:
    hf_hub_download_typed = cast(
        _HfHubDownload,
        getattr(import_module("huggingface_hub"), "hf_hub_download"),
    )
    return hf_hub_download_typed(
        repo_id=repo_id,
        filename=filename,
        local_dir=local_dir,
    )


@contextmanager
def _download_hf_weights(*, model_id: str) -> Generator[Path, None, None]:
    """Download one model artifact into an isolated protected staging directory."""
    staging_root = get_runtime_paths().weights / ".downloads" / uuid4().hex
    ensure_directory(staging_root)

    try:
        try:
            downloaded_path = Path(
                hf_hub_download(
                    repo_id=model_id,
                    filename=_DEFAULT_HF_WEIGHT_FILENAME,
                    local_dir=staging_root,
                )
            ).resolve()
        except Exception as exc:  # pragma: no cover - network boundary
            raise RuntimeError(
                "Failed to download safetensor weights from Hugging Face; "
                "ensure the repository provides a .safetensors artifact."
            ) from exc

        resolved_staging_root = staging_root.resolve()
        if not downloaded_path.is_relative_to(resolved_staging_root):
            raise RuntimeError(
                "Hugging Face returned a model artifact outside the protected "
                "download staging directory."
            )
        if downloaded_path.name != _DEFAULT_HF_WEIGHT_FILENAME:
            raise RuntimeError("Hugging Face returned an unexpected model artifact.")
        if not downloaded_path.is_file() or downloaded_path.stat().st_size <= 0:
            raise RuntimeError(
                "Hugging Face returned a missing or empty safetensor artifact."
            )

        yield downloaded_path
    finally:
        safe_rmtree(staging_root, missing_ok=True)


def _get_model_meta_class():
    """Lazy import to avoid circular imports"""
    from .model_meta import ModelMeta

    return ModelMeta


def get_latest_version_number_logic(
    cls: type["ModelMeta"], meta_name: str, model_name: str
) -> int:
    """
    Finds the highest numerical version for a given meta_name and model_name.
    Iterates through all versions, attempts to parse them as integers,
    and returns the maximum integer found. If no numeric versions are found,
    returns 0.
    """
    versions_qs = cls.objects.filter(
        name=meta_name, model__name=model_name
    ).values_list("version", flat=True)

    max_v = 0
    found_numeric_version = False

    for v_str in versions_qs:
        if v_str is None:  # Skip None versions
            continue
        try:
            v_int = int(v_str)
            if not found_numeric_version or v_int > max_v:
                max_v = v_int
            found_numeric_version = True
        except ValueError:
            logger.warning(
                f"Warning: Could not parse version string '{v_str}' as an integer for "
                f"meta_name='{meta_name}', model_name='{model_name}' while determining the max version."
            )

    return max_v if found_numeric_version else 0


@transaction.atomic
def create_from_file_logic(
    cls: type["ModelMeta"],
    meta_name: str,
    model_name: str,
    labelset_name: str,
    weights_file: str,
    labelset_version: int | str | None = None,
    requested_version: str | None = None,
    bump_if_exists: bool = False,
    **kwargs: Unpack[ModelMetaCreateFromFileKwargsData],
) -> "ModelMeta":
    """
    Logic to create or update a ModelMeta instance from a weights file.

    Handles finding related objects, versioning, file copying, and saving.
    """
    # --- Find Related Objects ---
    try:
        ai_model = AiModel.objects.get(name=model_name)
    except AiModel.DoesNotExist as exc:
        raise ValueError(f"AiModel with name '{model_name}' not found.") from exc

    labelset_qs = LabelSet.objects.filter(name=labelset_name)
    if isinstance(labelset_version, (int, str)) and labelset_version not in ("", -1):
        try:
            version_value = int(labelset_version)
        except (TypeError, ValueError):
            version_value = labelset_version
        labelset_qs = labelset_qs.filter(version=version_value)

    try:
        label_set = labelset_qs.get()
    except LabelSet.DoesNotExist as exc:
        raise ValueError(
            f"LabelSet '{labelset_name}' with version '{labelset_version}' not found."
        ) from exc
    except LabelSet.MultipleObjectsReturned:
        # Prefer the highest version when duplicates remain and no explicit version requested
        label_set = labelset_qs.order_by("-version").first()
        if not label_set:
            raise ValueError(f"LabelSet '{labelset_name}' could not be resolved.")

    # --- Determine Version ---
    target_version: str
    latest_version_num = get_latest_version_number_logic(cls, meta_name, model_name)

    if requested_version:
        target_version = str(requested_version)
        existing = cls.objects.filter(
            name=meta_name, model=ai_model, version=target_version
        ).first()
        if existing and not bump_if_exists:
            raise ValueError(
                f"ModelMeta '{meta_name}' version '{target_version}' for model '{model_name}' already exists. Use bump_if_exists=True to increment."
            )
        elif existing and bump_if_exists:
            target_version = str(latest_version_num + 1)
            logger.info(
                f"Bumping version for {meta_name}/{model_name} to {target_version}"
            )
    else:
        target_version = str(latest_version_num + 1)
        logger.info(
            f"Setting next version for {meta_name}/{model_name} to {target_version}"
        )

    # --- Prepare Weights File ---
    source_weights_path = Path(weights_file).resolve()
    if not source_weights_path.exists():
        raise FileNotFoundError(f"Weights file not found: {source_weights_path}")

    # Construct destination path within MEDIA_ROOT/get_runtime_paths().weights
    weights_filename = source_weights_path.name
    # Relative path for the FileField upload_to
    relative_dest_path = (
        Path(get_runtime_paths().weights.relative_to(get_runtime_paths().storage))
        / f"{meta_name}_v{target_version}_{weights_filename}"
    )
    # --- Create/Update ModelMeta Instance ---
    model_meta_kwargs = ModelMetaCreateFromFileKwargsPayload.model_validate(kwargs)
    defaults = {
        "labelset": label_set,
        "weights": relative_dest_path.as_posix(),
        **model_meta_kwargs.model_dump(mode="python"),
    }

    model_meta, created = cls.objects.update_or_create(
        name=meta_name,
        model=ai_model,
        version=target_version,
        defaults=defaults,
    )

    if created:
        logger.info(f"Created new ModelMeta: {model_meta}")
    else:
        logger.info(f"Updated existing ModelMeta: {model_meta}")

    try:
        with source_weights_path.open("rb") as source_file:
            saved_name = model_meta.weights.storage.save(
                relative_dest_path.as_posix(), ContentFile(source_file.read())
            )
        model_meta.weights.name = saved_name
        model_meta.save(update_fields=["weights"])
    except Exception as e:
        raise IOError("Failed to store model weights through encrypted storage") from e

    # --- Optionally update AiModel's active_meta ---
    # You might want to add logic here to automatically set the newly created/updated
    # meta as the active one for the AiModel, e.g.:
    ai_model.active_meta = model_meta
    ai_model.save()

    return model_meta


# --- Add other logic functions referenced by ModelMeta here ---
# (get_latest_version_number_logic, get_activation_function_logic, etc.)
# Placeholder for get_activation_function_logic
def get_activation_function_logic(activation_name: str) -> nn.Module:
    if activation_name.lower() == "sigmoid":
        return nn.Sigmoid()
    elif activation_name.lower() == "softmax":
        # Note: Softmax usually requires specifying the dimension
        return nn.Softmax(dim=1)  # Assuming dim=1 (channels) is common
    elif activation_name.lower() == "none":
        return nn.Identity()
    else:
        # Consider adding more activations or raising an error
        raise ValueError(f"Unsupported activation function: {activation_name}")


def _parse_float_sequence(
    value: str | int | float | Iterable[str | int | float],
    *,
    fallback: Iterable[float],
) -> list[float]:
    """Coerce stored normalisation strings/iterables to float lists."""

    if value == "":
        return list(fallback)

    tokens: Sequence[str | int | float]
    if isinstance(value, str):
        tokens = [tok.strip() for tok in value.split(",") if tok.strip()]
    elif isinstance(value, Iterable):
        tokens = list(value)
    else:
        tokens = [value]

    parsed: list[float] = []
    for token in tokens:
        try:
            parsed.append(float(str(token)))
        except (TypeError, ValueError):
            logger.warning(
                "Failed to parse normalisation value %r; using fallback", token
            )
            return list(fallback)

    return parsed or list(fallback)


def _parse_axes(axes_value: str | Iterable[str | int]) -> list[int]:
    """Normalise stored axis notation to integer indices.

    Historic metadata mixes numeric strings ("2,0,1") with symbolic tokens
    ("CHW", "HWC"). The inference code ultimately expects a list of integers,
    so we coerce common symbolic forms to their numeric equivalents and fall
    back to sequential indices when the format is unknown.
    """

    if not axes_value:
        return [0, 1, 2]

    if isinstance(axes_value, str):
        token_source = axes_value.strip()
        if "," in token_source:
            tokens = [
                token.strip() for token in token_source.split(",") if token.strip()
            ]
        else:
            tokens = [char for char in token_source if char.strip()]
    else:
        tokens = [str(token).strip() for token in axes_value if str(token).strip()]

    symbol_map = {"C": 0, "H": 1, "W": 2}
    parsed_axes: list[int] = []

    for idx, token in enumerate(tokens):
        normalised = token.upper()
        if normalised.lstrip("+-").isdigit():
            parsed_axes.append(int(normalised))
        elif normalised in symbol_map:
            parsed_axes.append(symbol_map[normalised])
        else:
            logger.warning("Unknown axes token '%s'; defaulting to index order", token)
            parsed_axes.append(idx)

    return parsed_axes or [0, 1, 2]


def get_inference_dataset_config_logic(
    model_meta: "ModelMeta",
) -> model_meta_contract.ModelMetaInferenceDatasetConfigPayload:
    # This would typically extract relevant fields from model_meta
    # for configuring a dataset during inference
    DEFAULT_MEAN = (0.45211223, 0.27139644, 0.19264949)
    DEFAULT_STD = (0.31418097, 0.21088019, 0.16059452)

    return model_meta_contract.ModelMetaInferenceDatasetConfigPayload.model_validate(
        {
            "mean": tuple(
                _parse_float_sequence(model_meta.mean, fallback=DEFAULT_MEAN)
            ),
            "std": tuple(_parse_float_sequence(model_meta.std, fallback=DEFAULT_STD)),
            "size_y": int(model_meta.size_y) if model_meta.size_y else 716,
            "size_x": int(model_meta.size_x) if model_meta.size_x else 716,
            "axes": tuple(_parse_axes(model_meta.axes)),
        }
    )


def get_config_dict_logic(
    model_meta: "ModelMeta",
) -> model_meta_contract.ModelMetaConfigPayload:
    # Returns a dictionary representation of the model's configuration
    return model_meta_contract.ModelMetaConfigPayload.model_validate(
        {
            "name": model_meta.name,
            "version": model_meta.version,
            "model_name": model_meta.model.name,
            "labelset_name": model_meta.labelset.name,
            "activation": model_meta.activation,
            "weights_path": model_meta.weights.path if model_meta.weights else "",
            "mean": model_meta.mean,
            "std": model_meta.std,
            "size_x": model_meta.size_x,
            "size_y": model_meta.size_y,
            "axes": model_meta.axes,
            "batchsize": model_meta.batchsize,
            "num_workers": model_meta.num_workers,
            "description": model_meta.description or "",
        }
    )


# Placeholder for get_model_meta_by_name_version_logic
def get_model_meta_by_name_version_logic(
    cls: type["ModelMeta"],
    meta_name: str,
    model_name: str,
    version: str | None = None,
) -> "ModelMeta":
    """
    Retrieves a ModelMeta instance by name, model name, and optionally version.
    If version is None, retrieves the latest version based on date_created.
    """
    try:
        ai_model = AiModel.objects.get(name=model_name)
    except AiModel.DoesNotExist as exc:
        raise cls.DoesNotExist(f"AiModel with name '{model_name}' not found.") from exc

    if version:
        try:
            return cls.objects.get(name=meta_name, model=ai_model, version=version)
        except Exception as exc:
            raise cls.DoesNotExist(
                f"ModelMeta '{meta_name}' version '{version}' for model '{model_name}' not found."
            ) from exc
    else:
        # Get latest version
        latest = (
            cls.objects.filter(name=meta_name, model=ai_model)
            .order_by("-date_created")
            .first()
        )
        if latest:
            return latest
        else:
            raise cls.DoesNotExist(
                f"No ModelMeta found for '{meta_name}' and model '{model_name}'."
            )


def _model_meta_weights_exist(model_meta: "ModelMeta") -> bool:
    if not model_meta.weights:
        return False
    try:
        return bool(model_meta.weights.name) and model_meta.weights.storage.exists(
            model_meta.weights.name
        )
    except (OSError, ValueError, RuntimeError):
        return False


def _copy_weights_to_existing_model_meta(
    model_meta: "ModelMeta",
    *,
    source_weights_path: Path,
) -> "ModelMeta":
    current_name = str(model_meta.weights.name or "").strip()
    if current_name:
        relative_dest_path = Path(current_name)
    else:
        relative_dest_path = (
            Path(get_runtime_paths().weights.relative_to(get_runtime_paths().storage))
            / f"{model_meta.name}_v{model_meta.version}_{source_weights_path.name}"
        )

    with source_weights_path.open("rb") as source_file:
        saved_name = model_meta.weights.storage.save(
            relative_dest_path.as_posix(), ContentFile(source_file.read())
        )
    model_meta.weights.name = saved_name
    model_meta.save(update_fields=["weights"])
    return model_meta


import re

from huggingface_hub import model_info


def infer_default_model_meta_from_hf(
    model_id: str,
) -> ModelMetaInferredDefaultsPayload:
    """
    Infers default model metadata (activation, normalization, input size)
    from a Hugging Face model_id using its tags and architecture.

    Returns:
        A dict with fields: name, activation, mean, std, size_x, size_y
    """

    if not (info := model_info(model_id)):
        logger.info(
            f"Could not retrieve model info for {model_id}, using ColoReg segmentation defaults."
        )
        return ModelMetaInferredDefaultsPayload.model_validate(
            {
                "name": "wg-lux/colo_segmentation_RegNetX800MF_base",
                "activation": "sigmoid",
                "mean": (0.45211223, 0.27139644, 0.19264949),
                "std": (0.31418097, 0.21088019, 0.16059452),
                "size_x": 716,
                "size_y": 716,
                "description": f"Defaults for unknown model {model_id}",
            }
        )

    # Extract architecture from tags or model_id ---
    tags = info.tags or []
    model_name = model_id.split("/")[-1].lower()

    # Heuristics for architecture and task
    architecture = next((t for t in tags if t.startswith("architecture:")), None)
    task = next((t for t in tags if t.startswith("task:")), None)

    # Default values
    activation = "sigmoid"
    size_x = size_y = 716
    mean = (0.45211223, 0.27139644, 0.19264949)
    std = (0.31418097, 0.21088019, 0.16059452)

    # --- 2. Task-based inference ---
    if task:
        if "segmentation" in task or "detection" in task:
            activation = "sigmoid"
        elif any(k in task for k in ["classification"]):
            activation = "softmax"

    # --- 3. Architecture-based inference ---
    if architecture:
        arch = architecture.replace("architecture:", "")
    else:
        arch = re.sub(r"[^a-z0-9]+", "_", model_name)

    return ModelMetaInferredDefaultsPayload.model_validate(
        {
            "name": arch,
            "activation": activation,
            "mean": mean,
            "std": std,
            "size_x": size_x,
            "size_y": size_y,
            "description": f"Inferred defaults for {model_id}",
        }
    )


def setup_default_from_huggingface_logic(
    cls: type["ModelMeta"],
    model_id: str,
    labelset_name: str | None = None,
    labelset_version: int | str | None = None,
) -> "ModelMeta":
    """
    Downloads model weights from Hugging Face and auto-fills ModelMeta fields.
    """
    meta = ModelMetaInferredDefaultsPayload.model_validate(
        infer_default_model_meta_from_hf(model_id)
    )

    ai_model, _ = AiModel.objects.get_or_create(name=meta.name)
    ai_model_like = cast(_AiModelActiveMetaLike, ai_model)
    if not labelset_name:
        labelset = LabelSet.objects.first()
        if not labelset:
            raise ValueError("No labelset found and no labelset_name provided")
    else:
        labelset_qs = LabelSet.objects.filter(name=labelset_name)
        if isinstance(labelset_version, (int, str)) and labelset_version not in (
            "",
            -1,
        ):
            try:
                version_value = int(labelset_version)
            except (TypeError, ValueError):
                version_value = labelset_version
            labelset_qs = labelset_qs.filter(version=version_value)
        labelset = labelset_qs.order_by("-version").first()
        if not labelset:
            raise ValueError(
                f"LabelSet '{labelset_name}' with version '{labelset_version}' not found."
            )

    model_meta = (
        _get_model_meta_class().objects.filter(name=meta.name, model=ai_model).first()
    )
    if model_meta:
        if _model_meta_weights_exist(model_meta):
            logger.info(
                f"ModelMeta {meta.name} for model {ai_model.name} already exists with available weights. Skipping creation."
            )
            if ai_model_like.active_meta_id != model_meta.pk:
                ai_model_like.active_meta = model_meta
                ai_model_like.save(update_fields=["active_meta"])
            return model_meta
        logger.warning(
            "ModelMeta %s for model %s exists but its weights file is missing; "
            "repairing from Hugging Face download.",
            meta.name,
            ai_model.name,
        )
        with _download_hf_weights(model_id=model_id) as weights_path:
            _copy_weights_to_existing_model_meta(
                model_meta,
                source_weights_path=weights_path,
            )
        if ai_model_like.active_meta_id != model_meta.pk:
            ai_model_like.active_meta = model_meta
            ai_model_like.save(update_fields=["active_meta"])
        return model_meta

    with _download_hf_weights(model_id=model_id) as weights_path:
        return create_from_file_logic(
            cls,
            meta_name=meta.name,
            model_name=ai_model.name,
            labelset_name=labelset.name,
            labelset_version=labelset.version,
            weights_file=weights_path.as_posix(),
            activation=meta.activation,
            mean=",".join(str(value) for value in meta.mean),
            std=",".join(str(value) for value in meta.std),
            size_x=meta.size_x,
            size_y=meta.size_y,
            description=meta.description,
        )
