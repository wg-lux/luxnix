import{l as e,ar as u}from"./main.js";function i(){return{isDebug:e(()=>u())}}export{i as u};
