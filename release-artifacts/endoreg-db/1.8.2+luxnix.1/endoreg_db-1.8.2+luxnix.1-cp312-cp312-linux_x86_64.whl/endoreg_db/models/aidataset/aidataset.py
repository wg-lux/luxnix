from __future__ import annotations

import uuid
from collections.abc import Iterable
from datetime import datetime
from typing import TYPE_CHECKING, Any, TypeAlias, TypeVar, Unpack

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import QuerySet
from lx_dtypes.models.contracts.aidataset_export import (
    AIDataSetExportPayload,
    AIDataSetExportSummary,
    AIDataSetFrameAnnotationExport,
    AIDataSetFrameLabelExport,
)
from lx_dtypes.models.contracts.aidataset_frame_buckets import (
    AIDataSetFrameBucketCount,
    AIDataSetFrameBucketDistribution,
    AIDataSetFrameBucketSummary,
    AIDataSetLabelDistributionEntry,
    AIDataSetLabelFrameBucketCount,
    AIDataSetTargetFrameBucket,
)

from endoreg_db.helpers.typing import DjangoModelSaveKwargs
from endoreg_db.schemas import (
    dump_ai_dataset_export_request_payload,
    dump_ai_dataset_export_summary,
    validate_ai_model_training_artifact_paths,
    validate_ai_model_training_command_kwargs,
    validate_ai_model_training_request_payload,
    validate_ai_model_training_result_payload,
)

__all__ = [
    "AIDataSet",
    "AIDataSetActiveLearningCandidateContract",
    "AIDataSetActiveLearningConfigContract",
    "AIDataSetActiveLearningSelectionContract",
    "AIDataSetExportArtifact",
    "AIDataSetExportPayload",
    "AIDataSetExportSummary",
    "AIDataSetFrameAnnotationExport",
    "AIDataSetFrameBucketCount",
    "AIDataSetFrameBucketDistribution",
    "AIDataSetFrameBucketSummary",
    "AIDataSetFrameLabelExport",
    "AIDataSetLabelDistributionEntry",
    "AIDataSetLabelFrameBucketCount",
    "AIDataSetScoredActiveLearningCandidateContract",
    "AIDataSetTargetFrameBucket",
    "AIModelTrainingRun",
]

if TYPE_CHECKING:
    from django.contrib.auth.models import User
    from endoreg_db.models import (
        ImageClassificationAnnotation,
        LabelVideoSegment,
        VideoFile,
        PatientExamination,
        StudyTableImport,
    )


AIDataSetRelation: TypeAlias = "AIDataSet | None"
_ModelT = TypeVar("_ModelT", bound=models.Model)


from lx_dtypes.models.contracts.ai_dataset import (
    AIDataSetActiveLearningCandidateContract,
    AIDataSetActiveLearningConfigContract,
    AIDataSetActiveLearningSelectionContract,
    AIDataSetScoredActiveLearningCandidateContract,
)


class AIDataSet(models.Model):
    """
    Aggregates persisted frame annotations and video-segment annotations for AI usage.

    Frame annotations come from the frame annotation workflow and are stored as
    `ImageClassificationAnnotation`. Timeline/video annotations come from the
    video examination workflow and are stored as `LabelVideoSegment`.

    The export helpers return a validated pydantic payload so downstream code can
    consume a single standardized structure.
    """

    DATASET_TYPE_IMAGE = "image"
    DATASET_TYPE_VIDEO = "video"
    DATASET_TYPE_TEXT = "text"

    DATASET_TYPE_CHOICES = [
        (DATASET_TYPE_IMAGE, "Image"),
        (DATASET_TYPE_VIDEO, "Video"),
        ("clinical", "Clinical records"),
    ]

    AI_MODEL_TYPE_IMAGE_MULTILABEL = "image_multilabel_classification"
    AI_MODEL_TYPE_VIDEO_SEGMENT_CLASSIFICATION = "video_segment_classification"

    name: models.CharField[str | None, Any] = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text='Human-readable identifier, e.g. "Legacy multilabel dataset v1".',
    )
    description: models.TextField[str | None, Any] = models.TextField(
        blank=True,
        null=True,
        help_text="Optional notes / explanation about this dataset.",
    )
    ai_model_type: models.CharField[str | None, Any] = models.CharField(
        max_length=255,
        default=AI_MODEL_TYPE_IMAGE_MULTILABEL,
        null=True,
        blank=True,
        help_text=(
            "AI model family this dataset is for, e.g. "
            '"image_multilabel_classification".'
        ),
    )
    dataset_type: models.CharField[str, Any] = models.CharField(
        max_length=32,
        choices=DATASET_TYPE_CHOICES,
        default=DATASET_TYPE_IMAGE,
        help_text=(
            "Primary annotation modality used for training. Export helpers may "
            "still include both frame and video annotations attached to the dataset."
        ),
    )
    owner: models.ForeignKey[User | None] = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="owned_datasets",
    )
    import_identity: models.UUIDField[uuid.UUID | None, uuid.UUID | None] = (
        models.UUIDField(null=True, blank=True, unique=True)
    )
    examinations: models.ManyToManyField[PatientExamination, models.Model] = (
        models.ManyToManyField(
            "PatientExamination", related_name="clinical_datasets", blank=True
        )
    )
    videos: models.ManyToManyField[VideoFile, models.Model] = models.ManyToManyField(
        "VideoFile", related_name="member_datasets", blank=True
    )
    import_receipts: models.ManyToManyField[StudyTableImport, models.Model] = (
        models.ManyToManyField("StudyTableImport", related_name="datasets", blank=True)
    )

    image_annotations: models.ManyToManyField[
        ImageClassificationAnnotation, ImageClassificationAnnotation
    ] = models.ManyToManyField(
        "ImageClassificationAnnotation",
        related_name="image_ai_datasets",
        blank=True,
        help_text=(
            "Frame-level annotations collected from the frame annotation workflow."
        ),
    )
    video_annotations: models.ManyToManyField[LabelVideoSegment, LabelVideoSegment] = (
        models.ManyToManyField(
            "LabelVideoSegment",
            related_name="video_ai_datasets",
            blank=True,
            help_text=(
                "Video-segment annotations collected from the video examination "
                "annotation workflow."
            ),
        )
    )
    created_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now_add=True,
        help_text="When this AIDataSet was created.",
    )
    updated_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now=True,
        help_text="When this AIDataSet was last modified.",
    )
    is_active: models.BooleanField[bool, Any] = models.BooleanField(
        default=True,
        help_text="Soft toggle to enable/disable this dataset for training.",
    )
    is_default_video_dataset: models.BooleanField[bool, Any] = models.BooleanField(
        default=False,
        help_text=(
            "Marks the one system-managed dataset assigned to every VideoFile when "
            "no explicit joined_dataset is supplied."
        ),
    )

    if TYPE_CHECKING:
        owner_id: int | None
        id: int

    @staticmethod
    def _coerce_objects(
        objects: Iterable[_ModelT] | QuerySet[_ModelT],
    ) -> list[_ModelT]:
        return list(objects)

    def get_image_annotations_queryset(self):
        return self.image_annotations

    def get_video_annotations_queryset(self):
        return self.video_annotations

    def get_annotations_queryset(self):
        """
        Backwards-compatible helper used by existing training code.
        """
        if self.dataset_type == self.DATASET_TYPE_IMAGE:
            return self.image_annotations
        if self.dataset_type == self.DATASET_TYPE_VIDEO:
            return self.video_annotations
        return self.image_annotations.none()

    def add_frame_annotations(
        self,
        annotations: (
            Iterable[ImageClassificationAnnotation]
            | QuerySet[ImageClassificationAnnotation]
        ),
    ) -> int:
        annotation_list = self._coerce_objects(annotations)
        if not annotation_list:
            return 0
        self.image_annotations.add(*annotation_list)
        return len(annotation_list)

    def add_video_annotations(
        self,
        segments: Iterable[LabelVideoSegment] | QuerySet[LabelVideoSegment],
    ) -> int:
        segment_list = self._coerce_objects(segments)
        if not segment_list:
            return 0
        self.video_annotations.add(*segment_list)
        return len(segment_list)

    def attach_video(
        self,
        video: VideoFile | int,
        *,
        include_frame_annotations: bool = True,
        include_video_annotations: bool = True,
        information_source_names: Iterable[str] | None = None,
    ) -> dict[str, int]:
        """
        Attach already-persisted annotations for a video to this dataset.

        This is the bridge from the existing frontend persistence flow to the dataset:
        the Vue screens write to `ImageClassificationAnnotation` and `LabelVideoSegment`,
        and the dataset aggregates those rows without duplicating annotation storage.
        """
        from endoreg_db.models import (
            ImageClassificationAnnotation,
            LabelVideoSegment,
            VideoFile,
        )

        if isinstance(video, int):
            video = VideoFile.objects.get(pk=video)

        if video.joined_dataset_id != self.pk:
            video.joined_dataset = self
            video.save(update_fields=["joined_dataset"])

        normalized_source_names = None
        if information_source_names is not None:
            normalized_source_names = [
                source_name.strip()
                for source_name in information_source_names
                if str(source_name).strip()
            ]

        frame_count = 0
        segment_count = 0

        if include_frame_annotations:
            frame_annotations = ImageClassificationAnnotation.objects.filter(
                frame__video=video
            )
            if normalized_source_names:
                frame_annotations = frame_annotations.filter(
                    information_source__name__in=normalized_source_names
                )
            frame_count = self.add_frame_annotations(frame_annotations.distinct())

        if include_video_annotations:
            video_segments = LabelVideoSegment.objects.filter(video_file=video)
            if normalized_source_names:
                video_segments = video_segments.filter(
                    source__name__in=normalized_source_names
                )
            segment_count = self.add_video_annotations(video_segments.distinct())

        return {
            "video_id": video.pk,
            "frame_annotation_count": frame_count,
            "video_annotation_count": segment_count,
        }

    def get_related_videos_queryset(self) -> QuerySet[VideoFile]:
        from endoreg_db.models import VideoFile

        image_video_ids = self.image_annotations.values_list(
            "frame__video_id", flat=True
        )
        segment_video_ids = self.video_annotations.values_list(
            "video_file_id", flat=True
        )
        return VideoFile.objects.filter(
            models.Q(joined_dataset=self)
            | models.Q(pk__in=set(image_video_ids).union(set(segment_video_ids)))
        ).distinct()

    def __str__(self) -> str:
        if self.name:
            return f"AIDataSet(id={self.id}, name={self.name})"
        return f"AIDataSet(id={self.id})"

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["is_default_video_dataset"],
                condition=models.Q(is_default_video_dataset=True),
                name="aidataset_one_default_video_dataset",
            )
        ]


class AIModelTrainingRun(models.Model):
    STATUS_QUEUED = "queued"
    STATUS_RUNNING = "running"
    STATUS_RETRY_WAIT = "retry_wait"
    STATUS_COMPLETED = "completed"
    STATUS_FAILED = "failed"
    STATUS_LOST = "lost"
    TERMINAL_STATUSES = frozenset({STATUS_COMPLETED, STATUS_FAILED, STATUS_LOST})
    STATUS_CHOICES = [
        (STATUS_QUEUED, "Queued"),
        (STATUS_RUNNING, "Running"),
        (STATUS_RETRY_WAIT, "Retry wait"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_FAILED, "Failed"),
        (STATUS_LOST, "Lost"),
    ]

    run_id: models.UUIDField[uuid.UUID, Any] = models.UUIDField(
        default=uuid.uuid4, editable=False, unique=True
    )
    dataset: models.ForeignKey[Any] = models.ForeignKey(
        AIDataSet,
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="model_training_runs",
    )
    dataset_name: models.CharField[str | None, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    dataset_type: models.CharField[str, Any] = models.CharField(
        max_length=32, blank=True
    )
    ai_model_type: models.CharField[str | None, Any] = models.CharField(
        max_length=255, blank=True
    )
    backbone_name: models.CharField[str, Any] = models.CharField(max_length=128)
    feature_mode: models.CharField[str, Any] = models.CharField(max_length=64)
    freeze_backbone: models.BooleanField[bool, Any] = models.BooleanField(default=True)
    epochs: models.PositiveIntegerField[int, Any] = models.PositiveIntegerField(
        default=10
    )
    batch_size: models.PositiveIntegerField[int, Any] = models.PositiveIntegerField(
        default=32
    )
    labelset_version: models.PositiveIntegerField[int, Any] = (
        models.PositiveIntegerField(default=1)
    )
    treat_unlabeled_as_negative: models.BooleanField[bool, Any] = models.BooleanField(
        default=True
    )
    backbone_checkpoint: models.TextField[str | None, Any] = models.TextField(
        blank=True, null=True
    )
    request_payload: models.JSONField[Any, Any] = models.JSONField(
        default=dict, blank=True
    )
    command_kwargs: models.JSONField[Any, Any] = models.JSONField(
        default=dict, blank=True
    )
    status: models.CharField[str, Any] = models.CharField(
        max_length=16,
        choices=STATUS_CHOICES,
        default=STATUS_QUEUED,
        db_index=True,
    )
    server_instance_id: models.CharField[str, Any] = models.CharField(
        max_length=64, blank=True, db_index=True
    )
    attempt_id: models.UUIDField[uuid.UUID | None, Any] = models.UUIDField(
        blank=True, null=True, editable=False
    )
    owner_id: models.CharField[str, Any] = models.CharField(
        max_length=255, blank=True, default="", editable=False
    )
    fencing_token: models.PositiveBigIntegerField[int, Any] = (
        models.PositiveBigIntegerField(default=0, editable=False)
    )
    heartbeat_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True, editable=False
    )
    lease_expires_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True, db_index=True, editable=False
    )
    retry_count: models.PositiveIntegerField[int, Any] = models.PositiveIntegerField(
        default=0
    )
    max_retries: models.PositiveIntegerField[int, Any] = models.PositiveIntegerField(
        default=3
    )
    next_retry_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True, db_index=True
    )
    dispatch_error: models.TextField[str, Any] = models.TextField(blank=True)
    result: models.JSONField[Any, Any] = models.JSONField(blank=True, null=True)
    artifact_paths: models.JSONField[dict[str, str]] = models.JSONField(
        default=dict, blank=True
    )
    error: models.TextField[str, Any] = models.TextField(blank=True)
    stdout: models.TextField[str, Any] = models.TextField(blank=True)
    stderr: models.TextField[str, Any] = models.TextField(blank=True)
    created_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now_add=True
    )
    updated_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now=True
    )
    started_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True
    )
    finished_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True
    )

    class Meta:
        indexes = [
            models.Index(fields=["status", "-created_at"], name="aid_train_status_idx"),
            models.Index(
                fields=["server_instance_id", "status"],
                name="aid_train_server_idx",
            ),
        ]
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(
                        status="running",
                        attempt_id__isnull=False,
                        heartbeat_at__isnull=False,
                        lease_expires_at__isnull=False,
                    )
                    & ~models.Q(owner_id="")
                )
                | (
                    ~models.Q(status="running")
                    & models.Q(
                        attempt_id__isnull=True,
                        owner_id="",
                        heartbeat_at__isnull=True,
                        lease_expires_at__isnull=True,
                    )
                ),
                name="aid_train_lease_state_consistent",
            )
        ]
        ordering = ["-created_at", "-id"]

    @property
    def run_key(self) -> str:
        return self.run_id.hex

    @property
    def is_terminal(self) -> bool:
        return self.status in self.TERMINAL_STATUSES

    def clean(self) -> None:
        super().clean()
        errors: dict[str, str] = {}
        try:
            self.request_payload = validate_ai_model_training_request_payload(
                self.request_payload
            )
        except ValueError as exc:
            errors["request_payload"] = str(exc)
        try:
            self.command_kwargs = validate_ai_model_training_command_kwargs(
                self.command_kwargs
            )
        except ValueError as exc:
            errors["command_kwargs"] = str(exc)
        try:
            self.result = validate_ai_model_training_result_payload(self.result)
        except ValueError as exc:
            errors["result"] = str(exc)
        try:
            self.artifact_paths = validate_ai_model_training_artifact_paths(
                self.artifact_paths
            )
        except ValueError as exc:
            errors["artifact_paths"] = str(exc)
        if errors:
            raise ValidationError(errors)

    def save(self, *args: object, **kwargs: Unpack[DjangoModelSaveKwargs]) -> None:
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"AIModelTrainingRun(run_id={self.run_key}, status={self.status})"


class AIDataSetExportArtifact(models.Model):
    STATUS_RUNNING = "running"
    STATUS_COMPLETED = "completed"
    STATUS_FAILED = "failed"
    STATUS_CHOICES = [
        (STATUS_RUNNING, "Running"),
        (STATUS_COMPLETED, "Completed"),
        (STATUS_FAILED, "Failed"),
    ]

    artifact_id: models.UUIDField[uuid.UUID, Any] = models.UUIDField(
        default=uuid.uuid4, editable=False, unique=True
    )
    dataset: models.ForeignKey[Any] = models.ForeignKey(
        AIDataSet,
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="export_artifacts",
    )
    dataset_name: models.CharField[str | None, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    dataset_type: models.CharField[str, Any] = models.CharField(
        max_length=32, blank=True
    )
    ai_model_type: models.CharField[str | None, Any] = models.CharField(
        max_length=255, blank=True
    )
    request_payload: models.JSONField[Any, Any] = models.JSONField(
        default=dict, blank=True
    )
    center_key: models.CharField[str | None, Any] = models.CharField(
        max_length=255, blank=True, null=True
    )
    all_centers: models.BooleanField[bool, Any] = models.BooleanField(default=False)
    only_validated: models.BooleanField[bool, Any] = models.BooleanField(default=True)
    status: models.CharField[str, Any] = models.CharField(
        max_length=16,
        choices=STATUS_CHOICES,
        default=STATUS_RUNNING,
        db_index=True,
    )
    output_path: models.TextField[str, Any] = models.TextField(blank=True)
    download_filename: models.CharField[str, Any] = models.CharField(
        max_length=255, blank=True
    )
    sha256: models.CharField[str, Any] = models.CharField(max_length=64, blank=True)
    byte_size: models.PositiveBigIntegerField[int, Any] = (
        models.PositiveBigIntegerField(default=0)
    )
    summary: models.JSONField[Any, Any] = models.JSONField(default=dict, blank=True)
    error: models.TextField[str, Any] = models.TextField(blank=True)
    created_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now_add=True
    )
    updated_at: models.DateTimeField[datetime, Any] = models.DateTimeField(
        auto_now=True
    )
    finished_at: models.DateTimeField[datetime | None, Any] = models.DateTimeField(
        blank=True, null=True
    )

    class Meta:
        indexes = [
            models.Index(
                fields=["status", "-created_at"], name="aid_export_status_idx"
            ),
            models.Index(
                fields=["dataset", "-created_at"], name="aid_export_dataset_idx"
            ),
        ]
        ordering = ["-created_at", "-id"]

    @property
    def artifact_key(self) -> str:
        return self.artifact_id.hex

    def clean(self) -> None:
        super().clean()
        errors: dict[str, str] = {}
        try:
            self.request_payload = dump_ai_dataset_export_request_payload(
                self.request_payload
            )
        except ValueError as exc:
            errors["request_payload"] = str(exc)
        try:
            self.summary = dump_ai_dataset_export_summary(self.summary)
        except ValueError as exc:
            errors["summary"] = str(exc)
        if errors:
            raise ValidationError(errors)

    def save(self, *args: object, **kwargs: Unpack[DjangoModelSaveKwargs]) -> None:
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return (
            f"AIDataSetExportArtifact(artifact_id={self.artifact_key}, "
            f"status={self.status})"
        )
