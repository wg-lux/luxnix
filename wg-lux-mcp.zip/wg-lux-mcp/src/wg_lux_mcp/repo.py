from __future__ import annotations

import subprocess
from pathlib import Path

from .config import settings


class RepositoryError(RuntimeError):
    pass


def resolve_repo(name: str) -> Path:
    try:
        path = settings.repositories[name]
    except KeyError as exc:
        allowed = ", ".join(sorted(settings.repositories))
        raise RepositoryError(f"Unknown repository {name!r}; allowed: {allowed}") from exc

    path = path.resolve()
    if not path.is_dir():
        raise RepositoryError(f"Repository path does not exist: {path}")
    if not (path / ".git").exists():
        raise RepositoryError(f"Not a Git repository: {path}")
    return path


def run_readonly(repo: Path, argv: list[str]) -> str:
    """Run a fixed, read-only command without a shell."""
    result = subprocess.run(
        argv,
        cwd=repo,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=settings.command_timeout_s,
        check=False,
        env={"PATH": "/run/current-system/sw/bin:/usr/bin:/bin"},
    )
    output = result.stdout[: settings.max_output_chars]
    if result.returncode != 0:
        raise RepositoryError(
            f"Command failed with exit code {result.returncode}: {' '.join(argv)}\n{output}"
        )
    return output
