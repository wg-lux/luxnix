from __future__ import annotations

import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import QuerySet

if TYPE_CHECKING:
    from ...medical.patient.patient_examination import PatientExamination
    from ...medical.patient.patient_lab_sample import PatientLabSample
    from ...medical.patient.patient_lab_value import PatientLabValue
    from ...report.patient_examination_report import PatientExaminationReport
    from ...medical.patient.patient_medication import PatientMedication
    from ...medical.patient.patient_medication_schedule import (
        PatientMedicationSchedule,
    )


class Case(models.Model):
    """
    Represents a clinical case, linking a patient to one or more examinations over a specific period.

    Attributes:
        patient (Patient): The patient associated with this case.
        patient_examinations (QuerySet[PatientExamination]): Examinations included in this case.
        hash (str): A hash value for the case when configured.
        start_date (datetime): The start date and time of the case.
        end_date (datetime): The end date and time of the case when closed.
        is_active (bool): Indicates if the case is currently active.
        is_closed (bool): Indicates if the case has been closed.
        is_deleted (bool): Indicates if the case is marked as deleted.
        created_at (datetime): Timestamp of case creation.
        updated_at (datetime): Timestamp of last case update.
    """

    case_id: models.UUIDField[Any, Any] = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False,
        db_index=True,
        help_text="Stable public identifier for the clinical case.",
    )
    patient: models.ForeignKey[Any] = models.ForeignKey(
        "Patient",
        on_delete=models.CASCADE,
        related_name="cases",
        help_text="The patient associated with this case.",
        db_index=True,
    )
    patient_examinations: "models.ManyToManyField[PatientExamination, PatientExamination]" = models.ManyToManyField(
        "PatientExamination",
        related_name="cases",
        help_text="The examinations included in this case.",
    )
    # Case media/report access is intentionally derived via case -> patient_examinations.
    # This avoids duplicate case-level links and keeps attachment ownership anchored
    # at PatientExamination for videos, reports, PDFs, and frames.
    patient_medications: "models.ManyToManyField[PatientMedication, PatientMedication]" = models.ManyToManyField(
        "PatientMedication", related_name="cases", blank=True
    )
    patient_medication_schedules: "models.ManyToManyField[PatientMedicationSchedule, PatientMedicationSchedule]" = models.ManyToManyField(
        "PatientMedicationSchedule", related_name="cases", blank=True
    )
    patient_lab_samples: "models.ManyToManyField[PatientLabSample, PatientLabSample]" = models.ManyToManyField(
        "PatientLabSample", related_name="cases", blank=True
    )
    patient_lab_values: "models.ManyToManyField[PatientLabValue, PatientLabValue]" = (
        models.ManyToManyField("PatientLabValue", related_name="cases", blank=True)
    )
    hash: models.CharField[Any, Any] = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="A hash value associated with the case when configured.",
    )

    start_date: models.DateTimeField[Any, Any] = models.DateTimeField(
        help_text="The start date and time of the case.", db_index=True
    )
    end_date: models.DateTimeField[Any, Any] = models.DateTimeField(
        null=True, blank=True, help_text="The end date and time of the case."
    )
    is_active: models.BooleanField[Any, Any] = models.BooleanField(
        default=True,
        help_text="Flag indicating if the case is currently active.",
        db_index=True,
    )
    is_closed: models.BooleanField[Any, Any] = models.BooleanField(
        default=False,
        help_text="Flag indicating if the case has been closed.",
        db_index=True,
    )
    is_deleted: models.BooleanField[Any, Any] = models.BooleanField(
        default=False,
        help_text="Flag indicating if the case is marked as deleted.",
        db_index=True,
    )
    created_at: models.DateTimeField[Any, Any] = models.DateTimeField(
        auto_now_add=True, help_text="The date and time the case was created."
    )
    updated_at: models.DateTimeField[Any, Any] = models.DateTimeField(
        auto_now=True, help_text="The date and time the case was last updated."
    )

    class Meta:
        ordering = ["-start_date", "patient"]
        verbose_name = "Case"
        verbose_name_plural = "Cases"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(end_date__isnull=True)
                | models.Q(end_date__gte=models.F("start_date")),
                name="case_end_not_before_start",
            )
        ]

    def clean(self) -> None:
        super().clean()
        if self.end_date is not None and self.end_date < self.start_date:
            raise ValidationError(
                {"end_date": "Case end date must not be earlier than start date."}
            )

    def __str__(self) -> str:
        string_representation = f"Case {self.pk} ({self.patient})"
        if self.start_date:
            string_representation += f" - {self.start_date.strftime('%Y-%m-%d')}"
        if self.end_date:
            string_representation += f" - {self.end_date.strftime('%Y-%m-%d')}"
        return string_representation

    def close(self, end_date: datetime | None = None) -> None:
        """Close this case with a provided end date or the current time."""
        from endoreg_db.services.cases.lifecycle import close_case

        close_case(instance=self, end_date=end_date)
        self.refresh_from_db()

    def reopen(self) -> None:
        """Reopen this case if it was closed."""
        from endoreg_db.services.cases.lifecycle import reopen_case

        reopen_case(instance=self)
        self.refresh_from_db()

    @property
    def reports(self) -> QuerySet["PatientExaminationReport"]:
        """Return all reports attached to examinations in this case."""
        from ...report.patient_examination_report import PatientExaminationReport

        return PatientExaminationReport.objects.filter(
            patient_examination__cases=self
        ).select_related("patient_examination")

    def mark_as_deleted(self) -> None:
        """Mark this case as deleted."""
        self.is_deleted = True
        self.is_active = False
        self.save()
