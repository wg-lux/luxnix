# state/audit_ledger.py
from __future__ import annotations

import logging
import math
import uuid
from typing import TYPE_CHECKING, Any, ClassVar, Unpack, cast

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.utils import OperationalError, ProgrammingError
from django.utils import timezone
from lx_dtypes.models.contracts.audit_ledger import AuditLedgerHashPayload
from lx_dtypes.models.contracts.json_types import JsonObject

from endoreg_db.helpers.typing import DjangoModelSaveKwargs

if TYPE_CHECKING:
    from django.contrib.auth.models import User


logger = logging.getLogger(__name__)


def _ledger_table_unavailable(exc: Exception) -> bool:
    message = str(exc).lower()
    return (
        "auditledger" in message
        or "ledgerhead" in message
        or "no such table" in message
        or "does not exist" in message
    )


def _canonical_json_value(value: object, *, field_name: str) -> object:
    """Validate and copy one value at the strict JSON persistence boundary."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{field_name} does not allow NaN or infinite floats")
        return value
    if isinstance(value, list):
        items = cast(list[object], value)
        return [_canonical_json_value(item, field_name=field_name) for item in items]
    if isinstance(value, dict):
        normalized: dict[str, object] = {}
        items = cast(dict[object, object], value)
        for key, item in items.items():
            if not isinstance(key, str):
                raise ValueError(f"{field_name} keys must be strings")
            normalized[key] = _canonical_json_value(item, field_name=field_name)
        return normalized
    raise ValueError(
        f"{field_name} contains unsupported JSON value type: {type(value).__name__}"
    )


def _canonical_json_object(value: object) -> JsonObject:
    if not isinstance(value, dict):
        raise ValueError("data must be a JSON object")
    return cast(
        JsonObject,
        _canonical_json_value(cast(dict[object, object], value), field_name="data"),
    )


class AuditLedger(models.Model):
    """
    Immutable audit ledger row.

    The cryptographic hash calculation is centralized in
    lx_dtypes.models.contracts.audit_ledger.AuditLedgerHashPayload.
    """

    objects: ClassVar[models.Manager["AuditLedger"]] = models.Manager()  # pyright: ignore[reportIncompatibleVariableOverride]

    id: models.UUIDField[Any, Any] = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )
    ts: models.DateTimeField[Any, Any] = models.DateTimeField(
        default=timezone.now,
        editable=False,
        db_index=True,
    )
    user: models.ForeignKey["User | None"] = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
    )
    object_type: models.CharField[Any, Any] = models.CharField(max_length=80)
    object_pk: models.CharField[Any, Any] = models.CharField(max_length=40)
    action: models.CharField[Any, Any] = models.CharField(max_length=40)
    data: models.JSONField[Any, Any] = models.JSONField()
    prev_hash: models.CharField[Any, Any] = models.CharField(
        max_length=64,
        editable=False,
    )
    hash: models.CharField[Any, Any] = models.CharField(
        max_length=64,
        editable=False,
    )

    class Meta:
        ordering = ["ts"]
        indexes = [models.Index(fields=["object_type", "object_pk"])]

    def clean(self) -> None:
        super().clean()
        try:
            self.data = _canonical_json_object(self.data)
        except ValueError as exc:
            raise ValidationError({"data": str(exc)}) from exc

    def save(self, *args: object, **kwargs: Unpack[DjangoModelSaveKwargs]) -> None:
        """
        Save a new immutable audit record, computing and linking cryptographic hashes.

        Raises:
            RuntimeError: If an attempt is made to modify an existing audit record.
        """
        if not self._state.adding:
            raise RuntimeError("AuditLedger rows are immutable")
        self.clean()
        with transaction.atomic():
            head = LedgerHead.lock()
            if head.last_entry is None:
                if head.current_hash != "0" * 64 or AuditLedger.objects.exists():
                    raise RuntimeError("Audit ledger head is inconsistent")
            elif (
                head.current_hash != head.last_entry.hash
                or head.last_entry.hash != head.last_entry._compute_hash()
            ):
                raise RuntimeError("Audit ledger head is inconsistent")
            object.__setattr__(self, "prev_hash", head.current_hash)
            object.__setattr__(self, "hash", self._compute_hash())
            super().save(*args, **kwargs)

            object.__setattr__(head, "current_hash", self.hash)
            object.__setattr__(head, "last_entry", self)
            head.save(update_fields=["current_hash", "last_entry", "updated_at"])

    @classmethod
    def verify_chain(cls) -> bool:
        """
        Verify every ledger row still matches its stored hash and previous link.
        """
        # Timestamp assignment precedes the append lock and is not append order.
        # Hold the writer lock while checking the persisted predecessor links.
        with transaction.atomic():
            head = LedgerHead.objects.select_for_update().filter(pk=1).first()
            records = list(cls.objects.select_related("user").all())
            if head is None:
                return not records
            by_hash = {record.hash: record for record in records}
            if len(by_hash) != len(records):
                return False
            expected_hash = head.current_hash
            last = by_hash.get(expected_hash)
            if (last.pk if last else None) != head.last_entry_id:
                return False
            while expected_hash != "0" * 64:
                record = by_hash.pop(expected_hash, None)
                if record is None or record.hash != record._compute_hash():
                    return False
                expected_hash = record.prev_hash
            return not by_hash

    def _compute_hash(self) -> str:
        user = getattr(self, "user", None)
        uid = None if user is None else str(getattr(user, "pk", None))

        payload = AuditLedgerHashPayload(
            ts=self.ts.isoformat(),
            id=str(self.id),
            uid=uid,
            obj=f"{self.object_type}:{self.object_pk}",
            act=self.action,
            data=cast(JsonObject, self.data),
            prev=self.prev_hash,
        )
        return payload.sha256_hex()

    @classmethod
    def append_identity_commit(
        cls,
        *,
        user: object | None = None,
        object_type: str,
        object_pk: str,
        data: JsonObject,
    ) -> "AuditLedger":
        """
        Append an immutable identity commit without requiring a user context.
        """
        audit_user = (
            cast(models.Model, user)
            if getattr(user, "is_authenticated", False)
            else None
        )
        return cls.objects.create(
            user=cast(Any, audit_user),
            object_type=object_type,
            object_pk=object_pk,
            action="identity_committed",
            data=data,
        )

    @classmethod
    def _distinct(cls, object_type: str, action: str) -> int:
        """
        Return the number of distinct objects for an audit action.
        """
        try:
            return (
                AuditLedger.objects.filter(object_type=object_type, action=action)
                .values("object_pk")
                .distinct()
                .count()
            )
        except (OperationalError, ProgrammingError) as exc:
            if _ledger_table_unavailable(exc):
                logger.warning(
                    "AuditLedger table unavailable while collecting counters; returning 0."
                )
                return 0
            raise

    def collect_counters(self) -> dict[str, int]:
        """
        Aggregate summary statistics for audit actions and object types.
        """
        return {
            "totalCases": AuditLedger._distinct("PatientExamination", "created"),
            "totalVideos": AuditLedger._distinct("VideoFile", "created"),
            "totalAnnotations": AuditLedger.objects.filter(
                action="annotation_added"
            ).count(),
            "totalAnonymizations": AuditLedger._distinct("VideoFile", "anonymized"),
            "totalImages": AuditLedger._distinct("Image", "created"),
            "videosCompleted": AuditLedger._distinct("VideoFile", "validated"),
            "videosAnonym": AuditLedger._distinct("VideoFile", "anonymized"),
        }


class LedgerHead(models.Model):
    """
    Singleton pointer to the current AuditLedger hash.

    Writers lock this row before appending, preventing concurrent ledger forks.
    """

    id: models.PositiveSmallIntegerField[Any, Any] = models.PositiveSmallIntegerField(
        primary_key=True,
        default=1,
        editable=False,
    )
    current_hash: models.CharField[Any, Any] = models.CharField(
        max_length=64,
        default="0" * 64,
        editable=False,
    )
    last_entry: models.ForeignKey["AuditLedger | None"] = models.ForeignKey(
        AuditLedger,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        editable=False,
        related_name="+",
    )
    updated_at: models.DateTimeField[Any, Any] = models.DateTimeField(
        auto_now=True,
    )

    objects: ClassVar[models.Manager["LedgerHead"]] = models.Manager()  # pyright: ignore[reportIncompatibleVariableOverride]

    if TYPE_CHECKING:
        last_entry_id: uuid.UUID | None

    class Meta:
        verbose_name = "Ledger Head"
        verbose_name_plural = "Ledger Heads"

    @classmethod
    def lock(cls) -> "LedgerHead":
        head, _created = cls.objects.get_or_create(pk=1)
        return cls.objects.select_for_update().get(pk=head.pk)
