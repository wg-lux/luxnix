from mcp import Client

from wg_lux_mcp.server import mcp


def test_capabilities_are_read_only() -> None:
    import anyio

    async def run() -> None:
        async with Client(mcp) as client:
            result = await client.call_tool("server_capabilities", {})
            assert result.structured_content is not None
            assert result.structured_content["mode"] == "read-only"
            assert result.structured_content["git_writes"] is False

    anyio.run(run)
