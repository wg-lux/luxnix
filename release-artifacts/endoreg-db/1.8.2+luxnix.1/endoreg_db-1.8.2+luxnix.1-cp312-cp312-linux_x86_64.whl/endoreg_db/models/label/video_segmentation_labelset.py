from __future__ import annotations

from typing import TYPE_CHECKING, Any

from django.db import models

if TYPE_CHECKING:
    from .video_segmentation_label import VideoSegmentationLabel


class VideoSegmentationLabelSetManager(models.Manager["VideoSegmentationLabelSet"]):
    def get_by_natural_key(self, name: str) -> "VideoSegmentationLabelSet":
        return self.get(name=name)


class VideoSegmentationLabelSet(models.Model):
    name: models.CharField[Any, Any] = models.CharField(max_length=255)
    description: models.TextField[str | None, Any] = models.TextField(
        blank=True, null=True
    )
    labels: models.ManyToManyField[VideoSegmentationLabel, VideoSegmentationLabel] = (
        models.ManyToManyField("VideoSegmentationLabel", related_name="labelsets")
    )

    objects = VideoSegmentationLabelSetManager()

    if TYPE_CHECKING:
        pass

    def natural_key(self) -> tuple[str]:
        return (self.name,)

    def __str__(self) -> str:
        return str(self.name)
