from __future__ import annotations

from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="WG_LUX_MCP_",
        env_file=".env",
        extra="ignore",
    )

    host: str = "127.0.0.1"
    port: int = 8765
    public_host: str = "mcp.example.org"
    bearer_token: str | None = None
    command_timeout_s: float = 8.0
    max_output_chars: int = 40_000

    repo_lx_annotate: Path = Field(default=Path("/srv/wg-lux/lx-annotate"))
    repo_endoreg_db: Path = Field(default=Path("/srv/wg-lux/endoreg-db"))
    repo_lx_data_models: Path = Field(default=Path("/srv/wg-lux/lx-data-models"))

    @field_validator("public_host")
    @classmethod
    def validate_public_host(cls, value: str) -> str:
        value = value.strip().lower()
        if not value or "/" in value or "://" in value:
            raise ValueError("public_host must be a hostname, e.g. mcp.example.org")
        return value

    @property
    def repositories(self) -> dict[str, Path]:
        return {
            "lx-annotate": self.repo_lx_annotate,
            "endoreg-db": self.repo_endoreg_db,
            "lx-data-models": self.repo_lx_data_models,
        }


settings = Settings()
