from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar, Any

from django.db import models

if TYPE_CHECKING:
    from ..administration.product.product_material import ProductMaterial


class UnitManager(models.Manager["Unit"]):
    def get_by_natural_key(self, name: str) -> "Unit":
        return self.get(name=name)


class Unit(models.Model):
    objects: ClassVar[UnitManager] = UnitManager()  # pyright: ignore[reportIncompatibleVariableOverride]

    name: models.CharField[Any, Any] = models.CharField(
        max_length=100
    )  # e.g. "Centimeter"
    description: models.TextField[str | None, str | None] = models.TextField(
        blank=True, null=True
    )  # e.g. "centimeters", "milimeters", "inches"
    abbreviation: models.CharField[Any, Any] = models.CharField(
        max_length=25, blank=True, null=True
    )  # e.g. "cm", "mm", "in"

    if TYPE_CHECKING:
        unit_product_materials: models.QuerySet["ProductMaterial"]

    def __str__(self) -> str:
        if self.abbreviation:
            return str(self.abbreviation)
        return str(self.name)

    def natural_key(self) -> tuple[str]:
        """
        Return a tuple containing the unit's name for natural key serialization.

        Returns:
            tuple: A single-element tuple with the unit's name.
        """
        return (str(self.name),)
